Imports RK.DataEngine
Imports RK.GenericParameters
Imports RK.GlobalTools
Imports System.IO
Imports System.Math

<Serializable()> Public Class Pedido

    Private _id_central_pedido As Int32
    Private _id_central_cotacao As Int32
    Private _id_estabelecimento As Int32
    Private _id_unid_producao As Int32
    Private _id_propriedade As Int32
    Private _id_fornecedor As Int32
    Private _dt_pedido As String
    Private _nr_total_pedido As Decimal
    Private _id_situacao_pedido As Int32
    Private _nm_situacao_pedido As String
    Private _id_modificador As Int32
    Private _dt_modificacao As String

    Public Property id_central_pedido() As Int32
        Get
            Return _id_central_pedido
        End Get
        Set(ByVal value As Int32)
            _id_central_pedido = value
        End Set
    End Property
    Public Property id_central_cotacao() As Int32
        Get
            Return _id_central_cotacao
        End Get
        Set(ByVal value As Int32)
            _id_central_cotacao = value
        End Set
    End Property
    Public Property id_estabelecimento() As Int32
        Get
            Return _id_estabelecimento
        End Get
        Set(ByVal value As Int32)
            _id_estabelecimento = value
        End Set
    End Property
    Public Property id_unid_producao() As Int32
        Get
            Return _id_unid_producao
        End Get
        Set(ByVal value As Int32)
            _id_unid_producao = value
        End Set
    End Property
    Public Property id_propriedade() As Int32
        Get
            Return _id_propriedade
        End Get
        Set(ByVal value As Int32)
            _id_propriedade = value
        End Set
    End Property
    Public Property id_fornecedor() As Int32
        Get
            Return _id_fornecedor
        End Get
        Set(ByVal value As Int32)
            _id_fornecedor = value
        End Set
    End Property
    Public Property id_situacao_pedido() As Int32
        Get
            Return _id_situacao_pedido
        End Get
        Set(ByVal value As Int32)
            _id_situacao_pedido = value
        End Set
    End Property
    Public Property nm_situacao_pedido() As String
        Get
            Return _nm_situacao_pedido
        End Get
        Set(ByVal value As String)
            _nm_situacao_pedido = value
        End Set
    End Property
    Public Property dt_pedido() As String
        Get
            Return _dt_pedido
        End Get
        Set(ByVal value As String)
            _dt_pedido = value
        End Set
    End Property

    Public Property nr_total_pedido() As Decimal
        Get
            Return _nr_total_pedido
        End Get
        Set(ByVal value As Decimal)
            _nr_total_pedido = value
        End Set
    End Property
    Public Property dt_modificacao() As String
        Get
            Return _dt_modificacao
        End Get
        Set(ByVal value As String)
            _dt_modificacao = value
        End Set
    End Property
    Public Property id_modificador() As Int32
        Get
            Return _id_modificador
        End Get
        Set(ByVal value As Int32)
            _id_modificador = value
        End Set
    End Property

    Public Sub New(ByVal id As Int32)

        Me.id_central_pedido = id
        loadPedido()

    End Sub

    Public Sub New()

    End Sub
    Public Function getPedidoByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getCentralPedido", parameters, "ms_central_pedido")
            Return dataSet

        End Using

    End Function

    Private Sub loadPedido()

        Dim dataSet As DataSet = getPedidoByFilters()
        ParametersEngine.persistObjectValues(dataSet.Tables(0).Rows(0), Me)

    End Sub


    Public Function insertCentralPedido() As Int32

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_insertCentralPedido", parameters, ExecuteType.Insert), Int32)

        End Using


    End Function


    Public Sub updateCentralPedido()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacao", parameters, ExecuteType.Update)

        End Using

    End Sub

    Public Sub deleteCentralPedido()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_deleteCentralPedido", parameters, ExecuteType.Delete)

        End Using


    End Sub

End Class
