Imports RK.DataEngine
Imports RK.GenericParameters
Imports RK.GlobalTools
Imports System.IO
Imports System.Math

<Serializable()> Public Class Cotacao

    Private _id_central_cotacao As Int32
    Private _id_central_cotacao_item As Int32
    Private _id_estabelecimento As Int32
    Private _id_central_justificativa_aprovacao As Int32
    Private _id_central_status_aprovacao As Int32  ' 1-Reprovado Tecnico 2-Aprovado Tecnico 3-Reprovado Gestor 4-Aprovado Gestor (ms_zcentral_status_aprovacao)
    Private _id_tecnico As Int32
    Private _dt_cotacao_inicio As String
    Private _dt_cotacao_fim As String
    Private _id_unid_producao As Int32
    Private _id_propriedade As Int32
    Private _id_produtor As Int32
    Private _id_item As Int32
    Private _st_ver_mercado As String
    Private _st_produtor_informado As String
    Private _id_situacao_cotacao As Int32
    Private _nm_situacao_cotacao As String
    Private _dt_cotacao As String
    Private _nr_total_cotacao As Decimal
    Private _id_modificador As Int32
    Private _dt_modificacao As String
    'Private _st_aprovado As String  ' Desabilitado Adriana
    Private _st_selecao As String

    Public Property id_central_cotacao() As Int32
        Get
            Return _id_central_cotacao
        End Get
        Set(ByVal value As Int32)
            _id_central_cotacao = value
        End Set
    End Property
    Public Property id_central_cotacao_item() As Int32
        Get
            Return _id_central_cotacao_item
        End Get
        Set(ByVal value As Int32)
            _id_central_cotacao_item = value
        End Set
    End Property
    Public Property id_estabelecimento() As Int32
        Get
            Return _id_estabelecimento
        End Get
        Set(ByVal value As Int32)
            _id_estabelecimento = value
        End Set
    End Property
    Public Property id_tecnico() As Int32
        Get
            Return _id_tecnico
        End Get
        Set(ByVal value As Int32)
            _id_tecnico = value
        End Set
    End Property
    Public Property dt_cotacao_inicio() As String
        Get
            Return _dt_cotacao_inicio
        End Get
        Set(ByVal value As String)
            _dt_cotacao_inicio = value
        End Set
    End Property
    Public Property dt_cotacao_fim() As String
        Get
            Return _dt_cotacao_fim
        End Get
        Set(ByVal value As String)
            _dt_cotacao_fim = value
        End Set
    End Property
    Public Property id_central_justificativa_aprovacao() As Int32
        Get
            Return _id_central_justificativa_aprovacao
        End Get
        Set(ByVal value As Int32)
            _id_central_justificativa_aprovacao = value
        End Set
    End Property
    Public Property id_unid_producao() As Int32
        Get
            Return _id_unid_producao
        End Get
        Set(ByVal value As Int32)
            _id_unid_producao = value
        End Set
    End Property
    Public Property id_propriedade() As Int32
        Get
            Return _id_propriedade
        End Get
        Set(ByVal value As Int32)
            _id_propriedade = value
        End Set
    End Property
    Public Property id_produtor() As Int32
        Get
            Return _id_produtor
        End Get
        Set(ByVal value As Int32)
            _id_produtor = value
        End Set
    End Property
    Public Property id_item() As Int32
        Get
            Return _id_item
        End Get
        Set(ByVal value As Int32)
            _id_item = value
        End Set
    End Property
    Public Property id_situacao_cotacao() As Int32
        Get
            Return _id_situacao_cotacao
        End Get
        Set(ByVal value As Int32)
            _id_situacao_cotacao = value
        End Set
    End Property
    Public Property nm_situacao_cotacao() As String
        Get
            Return _nm_situacao_cotacao
        End Get
        Set(ByVal value As String)
            _nm_situacao_cotacao = value
        End Set
    End Property
    Public Property dt_cotacao() As String
        Get
            Return _dt_cotacao
        End Get
        Set(ByVal value As String)
            _dt_cotacao = value
        End Set
    End Property

    Public Property nr_total_cotacao() As Decimal
        Get
            Return _nr_total_cotacao
        End Get
        Set(ByVal value As Decimal)
            _nr_total_cotacao = value
        End Set
    End Property
    Public Property dt_modificacao() As String
        Get
            Return _dt_modificacao
        End Get
        Set(ByVal value As String)
            _dt_modificacao = value
        End Set
    End Property
    Public Property id_modificador() As Int32
        Get
            Return _id_modificador
        End Get
        Set(ByVal value As Int32)
            _id_modificador = value
        End Set
    End Property
    Public Property id_central_status_aprovacao() As String
        Get
            Return _id_central_status_aprovacao
        End Get
        Set(ByVal value As String)
            _id_central_status_aprovacao = value
        End Set
    End Property
    Public Property st_selecao() As String
        Get
            Return _st_selecao
        End Get
        Set(ByVal value As String)
            _st_selecao = value
        End Set
    End Property
    Public Property st_ver_mercado() As String
        Get
            Return _st_ver_mercado
        End Get
        Set(ByVal value As String)
            _st_ver_mercado = value
        End Set
    End Property
    Public Property st_produtor_informado() As String
        Get
            Return _st_produtor_informado
        End Get
        Set(ByVal value As String)
            _st_produtor_informado = value
        End Set
    End Property

    Public Sub New(ByVal id As Int32)

        Me.id_central_cotacao = id
        loadCotacao()

    End Sub

    Public Sub New()

    End Sub
    Public Function getCotacaoByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getCotacao", parameters, "ms_central_cotacao")
            Return dataSet

        End Using

    End Function

    Private Sub loadCotacao()

        Dim dataSet As DataSet = getCotacaoByFilters()
        ParametersEngine.persistObjectValues(dataSet.Tables(0).Rows(0), Me)

    End Sub

    Public Function getCentralCotacaoByTecnico() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getCentralCotacaoTecnico", parameters, "ms_central_cotacao")
            Return dataSet

        End Using

    End Function
    Public Function getCentralCotacaoByGestor() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getCentralCotacaoGestor", parameters, "ms_central_cotacao")
            Return dataSet

        End Using

    End Function
    Public Function getCentralCotacoeseSeusItensbyFilter() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getCentralCotacaoeSeusItens", parameters, "ms_central_cotacao_item")
            Return dataSet

        End Using

    End Function

    Public Function insertCotacao() As Int32

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_insertCentralCotacao", parameters, ExecuteType.Insert), Int32)

        End Using


    End Function


    Public Sub updateCotacao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacao", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateCotacaoAprovarTodos()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCotacaoAprovarTodos", parameters, ExecuteType.Update)

        End Using

    End Sub


    Public Sub deleteCotacao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_deleteCentralCotacao", parameters, ExecuteType.Delete)

        End Using


    End Sub
    Public Sub updateAdiantamentoSelecao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCotacaoSelecao", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateCentralCotacaoAprovarSelecionados()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacaoAprovarSelecionados", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateCentralCotacaoAprovador()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacaoAprovador", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateCentralCotacaoTodos1N()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacaoTodos1N", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateCentralCotacaoSelecao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateCentralCotacaoSelecao", parameters, ExecuteType.Update)

        End Using

    End Sub

End Class
