Imports RK.DataEngine
Imports RK.GenericParameters
Imports RK.GlobalTools
Imports System.IO
Imports System.Math
Imports System.Data


<Serializable()> Public Class Romaneio
    Private _id_romaneio As Int32
    Private _id_romaneio_transbordo As Int32
    Private _id_estabelecimento As Int32
    Private _id_cooperativa As Int32
    Private _cd_cooperativa As String
    Private _nm_cooperativa As String
    Private _id_transportador As Int32
    Private _cd_transportador As String
    Private _nm_transportador As String
    Private _cd_cnh As String
    Private _nm_motorista As String
    Private _id_motorista As Int32
    Private _ds_placa As String
    Private _id_linha As Int32
    Private _ds_linha As String
    Private _dt_hora_entrada As String
    Private _dt_hora_entrada_ini As String 'fran 23/09/2009 i
    Private _dt_hora_entrada_fim As String 'fran 23/09/2009 f
    Private _dt_hora_saida As String
    Private _dt_pesagem_inicial As String
    Private _dt_pesagem_final As String
    Private _nr_tara As Decimal
    Private _nr_pesagem_inicial As Decimal
    Private _nr_pesagem_final As Decimal
    Private _nr_peso_liquido As Decimal
    Private _nr_peso_liquido_caderneta As Decimal
    Private _nr_peso_liquido_nota As Decimal
    Private _nr_nota_fiscal As String
    Private _nr_serie_nota_fiscal As String
    Private _nr_valor_nota_fiscal As Decimal
    Private _dt_saida_nota As String
    Private _id_item As Int32
    Private _nm_item As String
    Private _nr_caderneta As Int32
    Private _id_st_romaneio As Int32
    Private _id_st_analise_global As Int32
    Private _id_st_analise_compartimento As Int32
    Private _id_st_analise_uproducao As Int32
    Private _id_coleta_transmissao As Int32
    Private _id_criacao As Int32
    Private _id_modificador As Int32
    Private _dt_criacao As String
    Private _dt_modificacao As String
    Private _romaneio_compartimento As Romaneio_Compartimento
    Private _ds_estabelecimento As String
    Private _ds_transportador As String
    Private _nm_st_romaneio As String
    Private _st_reanalise As String
    Private _nm_st_analise_compartimento As String
    Private _nm_st_analise_uproducao As String
    Private _data_inicio As String
    Private _data_fim As String
    Private _rc_ds_placa As New ArrayList
    Private _rc_id_compartimento As New ArrayList
    Private _rc_nr_total_volume As New ArrayList
    Private _id_linha_ini As Int32
    Private _id_linha_fim As Int32
    Private _nr_peso_liquido_nota_transf As Decimal
    Private _nr_nota_fiscal_transf As String
    Private _nr_serie_nota_fiscal_transf As String
    Private _dt_emissao_nota_transf As String
    Private _st_romaneio_transbordo As String
    Private _total_volume_max_compartimentos As Decimal
    Private _dt_transmissao_ini As String 'Fran 29/11/2008
    Private _dt_transmissao_fim As String 'Fran 29/11/2008
    Private _dt_transmissao As String 'Fran 29/11/2008
    Private _nm_linha As String 'Fran 29/11/2008
    Private _ds_placa_frete As String
    Private _path_arquivofrete As String
    Private _st_exportacao_frete As String
    Private _id_exportacao_frete_execucao As Int32
    Private _id_exportacao_frete_execucao_itens As Int32



    Public Property romaneio_compartimento() As Romaneio_Compartimento

        Get
            Return _romaneio_compartimento
        End Get

        Set(ByVal value As Romaneio_Compartimento)
            _romaneio_compartimento = value
        End Set
    End Property
    Public Property id_romaneio() As Int32
        Get
            Return _id_romaneio
        End Get
        Set(ByVal value As Int32)
            _id_romaneio = value
        End Set
    End Property
    Public Property id_romaneio_transbordo() As Int32
        Get
            Return _id_romaneio_transbordo
        End Get
        Set(ByVal value As Int32)
            _id_romaneio_transbordo = value
        End Set
    End Property

    Public Property id_estabelecimento() As Int32
        Get
            Return _id_estabelecimento
        End Get
        Set(ByVal value As Int32)
            _id_estabelecimento = value
        End Set
    End Property
    Public Property id_cooperativa() As Int32
        Get
            Return _id_cooperativa
        End Get
        Set(ByVal value As Int32)
            _id_cooperativa = value
        End Set
    End Property
    Public Property cd_cooperativa() As String
        Get
            Return _cd_cooperativa
        End Get
        Set(ByVal value As String)
            _cd_cooperativa = value
        End Set
    End Property
    Public Property nm_cooperativa() As String
        Get
            Return _nm_cooperativa
        End Get
        Set(ByVal value As String)
            _nm_cooperativa = value
        End Set
    End Property
    Public Property id_transportador() As Int32
        Get
            Return _id_transportador
        End Get
        Set(ByVal value As Int32)
            _id_transportador = value
        End Set
    End Property
    Public Property cd_transportador() As String
        Get
            Return _cd_transportador
        End Get
        Set(ByVal value As String)
            _cd_transportador = value
        End Set
    End Property
    Public Property st_romaneio_transbordo() As String
        Get
            Return _st_romaneio_transbordo
        End Get
        Set(ByVal value As String)
            _st_romaneio_transbordo = value
        End Set
    End Property
    Public Property nm_transportador() As String
        Get
            Return _nm_transportador
        End Get
        Set(ByVal value As String)
            _nm_transportador = value
        End Set
    End Property
    Public Property cd_cnh() As String
        Get
            Return _cd_cnh
        End Get
        Set(ByVal value As String)
            _cd_cnh = value
        End Set
    End Property
    Public Property nm_motorista() As String
        Get
            Return _nm_motorista
        End Get
        Set(ByVal value As String)
            _nm_motorista = value
        End Set
    End Property
    Public Property id_motorista() As Int32
        Get
            Return _id_motorista
        End Get
        Set(ByVal value As Int32)
            _id_motorista = value
        End Set
    End Property

    Public Property ds_placa() As String
        Get
            Return _ds_placa
        End Get
        Set(ByVal value As String)
            _ds_placa = value
        End Set
    End Property
    Public Property ds_placa_frete() As String
        Get
            Return _ds_placa_frete
        End Get
        Set(ByVal value As String)
            _ds_placa_frete = value
        End Set
    End Property

    Public Property id_linha() As Int32
        Get
            Return _id_linha
        End Get
        Set(ByVal value As Int32)
            _id_linha = value
        End Set
    End Property
    Public Property ds_linha() As String
        Get
            Return _ds_linha
        End Get
        Set(ByVal value As String)
            _ds_linha = value
        End Set
    End Property

    Public Property id_coleta_transmissao() As Int32
        Get
            Return _id_coleta_transmissao
        End Get
        Set(ByVal value As Int32)
            _id_coleta_transmissao = value
        End Set
    End Property

    Public Property dt_hora_entrada() As String
        Get
            Return _dt_hora_entrada
        End Get
        Set(ByVal value As String)
            _dt_hora_entrada = value
        End Set
    End Property
    Public Property dt_hora_entrada_ini() As String
        Get
            Return _dt_hora_entrada_ini
        End Get
        Set(ByVal value As String)
            _dt_hora_entrada_ini = value
        End Set
    End Property
    Public Property dt_hora_entrada_fim() As String
        Get
            Return _dt_hora_entrada_fim
        End Get
        Set(ByVal value As String)
            _dt_hora_entrada_fim = value
        End Set
    End Property

    Public Property dt_hora_saida() As String
        Get
            Return _dt_hora_saida
        End Get
        Set(ByVal value As String)
            _dt_hora_saida = value
        End Set
    End Property

    Public Property dt_pesagem_inicial() As String
        Get
            Return _dt_pesagem_inicial
        End Get
        Set(ByVal value As String)
            _dt_pesagem_inicial = value
        End Set
    End Property

    Public Property dt_pesagem_final() As String
        Get
            Return _dt_pesagem_final
        End Get
        Set(ByVal value As String)
            _dt_pesagem_final = value
        End Set
    End Property

    Public Property nr_tara() As Decimal
        Get
            Return _nr_tara
        End Get
        Set(ByVal value As Decimal)
            _nr_tara = value
        End Set
    End Property

    Public Property nr_pesagem_inicial() As Decimal
        Get
            Return _nr_pesagem_inicial
        End Get
        Set(ByVal value As Decimal)
            _nr_pesagem_inicial = value
        End Set
    End Property

    Public Property nr_pesagem_final() As Decimal
        Get
            Return _nr_pesagem_final
        End Get
        Set(ByVal value As Decimal)
            _nr_pesagem_final = value
        End Set
    End Property

    Public Property nr_peso_liquido() As Decimal
        Get
            Return _nr_peso_liquido
        End Get
        Set(ByVal value As Decimal)
            _nr_peso_liquido = value
        End Set
    End Property

    Public Property nr_peso_liquido_caderneta() As Decimal
        Get
            Return _nr_peso_liquido_caderneta
        End Get
        Set(ByVal value As Decimal)
            _nr_peso_liquido_caderneta = value
        End Set
    End Property
    Public Property nr_peso_liquido_nota() As Decimal
        Get
            Return _nr_peso_liquido_nota
        End Get
        Set(ByVal value As Decimal)
            _nr_peso_liquido_nota = value
        End Set
    End Property
    Public Property nr_nota_fiscal() As String
        Get
            Return _nr_nota_fiscal
        End Get
        Set(ByVal value As String)
            _nr_nota_fiscal = value
        End Set
    End Property
    Public Property nr_serie_nota_fiscal() As String
        Get
            Return _nr_serie_nota_fiscal
        End Get
        Set(ByVal value As String)
            _nr_serie_nota_fiscal = value
        End Set
    End Property

    Public Property nr_valor_nota_fiscal() As Decimal
        Get
            Return _nr_valor_nota_fiscal
        End Get
        Set(ByVal value As Decimal)
            _nr_valor_nota_fiscal = value
        End Set
    End Property
    Public Property dt_saida_nota() As String
        Get
            Return _dt_saida_nota
        End Get
        Set(ByVal value As String)
            _dt_saida_nota = value
        End Set
    End Property
    Public Property id_item() As Int32
        Get
            Return _id_item
        End Get
        Set(ByVal value As Int32)
            _id_item = value
        End Set
    End Property
    Public Property nm_item() As String
        Get
            Return _nm_item
        End Get
        Set(ByVal value As String)
            _nm_item = value
        End Set
    End Property

    Public Property ds_transportador() As String
        Get
            Return _ds_transportador
        End Get
        Set(ByVal value As String)
            _ds_transportador = value
        End Set
    End Property
    Public Property ds_estabelecimento() As String
        Get
            Return _ds_estabelecimento
        End Get
        Set(ByVal value As String)
            _ds_estabelecimento = value
        End Set
    End Property
    Public Property id_st_romaneio() As Int32
        Get
            Return _id_st_romaneio
        End Get
        Set(ByVal value As Int32)
            _id_st_romaneio = value
        End Set
    End Property

    Public Property id_st_analise_global() As Int32
        Get
            Return _id_st_analise_global
        End Get
        Set(ByVal value As Int32)
            _id_st_analise_global = value
        End Set
    End Property

    Public Property id_st_analise_compartimento() As Int32
        Get
            Return _id_st_analise_compartimento
        End Get
        Set(ByVal value As Int32)
            _id_st_analise_compartimento = value
        End Set
    End Property

    Public Property id_st_analise_uproducao() As Int32
        Get
            Return _id_st_analise_uproducao
        End Get
        Set(ByVal value As Int32)
            _id_st_analise_uproducao = value
        End Set
    End Property

    Public Property nm_st_romaneio() As String
        Get
            Return _nm_st_romaneio
        End Get
        Set(ByVal value As String)
            _nm_st_romaneio = value
        End Set
    End Property
    Public Property st_reanalise() As String
        Get
            Return _st_reanalise
        End Get
        Set(ByVal value As String)
            _st_reanalise = value
        End Set
    End Property
    Public Property nm_st_analise_compartimento() As String
        Get
            Return _nm_st_analise_compartimento
        End Get
        Set(ByVal value As String)
            _nm_st_analise_compartimento = value
        End Set
    End Property
    Public Property rc_nr_total_volume() As ArrayList
        Get
            Return _rc_nr_total_volume
        End Get
        Set(ByVal value As ArrayList)
            _rc_nr_total_volume = value
        End Set
    End Property

    Public Property rc_ds_placa() As ArrayList
        Get
            Return _rc_ds_placa
        End Get
        Set(ByVal value As ArrayList)
            _rc_ds_placa = value
        End Set
    End Property
    Public Property rc_id_compartimento() As ArrayList
        Get
            Return _rc_id_compartimento
        End Get
        Set(ByVal value As ArrayList)
            _rc_id_compartimento = value
        End Set
    End Property
    Public Property nm_st_analise_uproducao() As String
        Get
            Return _nm_st_analise_uproducao
        End Get
        Set(ByVal value As String)
            _nm_st_analise_uproducao = value
        End Set
    End Property
    Public Property nr_caderneta() As Int32
        Get
            Return _nr_caderneta
        End Get
        Set(ByVal value As Int32)
            _nr_caderneta = value
        End Set
    End Property
    Public Property id_criacao() As Int32
        Get
            Return _id_criacao
        End Get
        Set(ByVal value As Int32)
            _id_criacao = value
        End Set
    End Property

    Public Property id_modificador() As Int32
        Get
            Return _id_modificador
        End Get
        Set(ByVal value As Int32)
            _id_modificador = value
        End Set
    End Property

    Public Property dt_criacao() As String
        Get
            Return _dt_criacao
        End Get
        Set(ByVal value As String)
            _dt_criacao = value
        End Set
    End Property

    Public Property dt_modificacao() As String
        Get
            Return _dt_modificacao
        End Get
        Set(ByVal value As String)
            _dt_modificacao = value
        End Set
    End Property
    Public Property data_inicio() As String
        Get
            Return _data_inicio
        End Get
        Set(ByVal value As String)
            _data_inicio = value
        End Set
    End Property
    Public Property data_fim() As String
        Get
            Return _data_fim
        End Get
        Set(ByVal value As String)
            _data_fim = value
        End Set
    End Property
    Public Property id_linha_ini() As Int32
        Get
            Return _id_linha_ini
        End Get
        Set(ByVal value As Int32)
            _id_linha_ini = value
        End Set
    End Property
    Public Property id_linha_fim() As Int32
        Get
            Return _id_linha_fim
        End Get
        Set(ByVal value As Int32)
            _id_linha_fim = value
        End Set
    End Property
    Public Property nr_peso_liquido_nota_transf() As Decimal
        Get
            Return _nr_peso_liquido_nota_transf
        End Get
        Set(ByVal value As Decimal)
            _nr_peso_liquido_nota_transf = value
        End Set
    End Property
    Public Property nr_nota_fiscal_transf() As String
        Get
            Return _nr_nota_fiscal_transf
        End Get
        Set(ByVal value As String)
            _nr_nota_fiscal_transf = value
        End Set
    End Property
    Public Property nr_serie_nota_fiscal_transf() As String
        Get
            Return _nr_serie_nota_fiscal_transf
        End Get
        Set(ByVal value As String)
            _nr_serie_nota_fiscal_transf = value
        End Set
    End Property

    Public Property dt_emissao_nota_transf() As String
        Get
            Return _dt_emissao_nota_transf
        End Get
        Set(ByVal value As String)
            _dt_emissao_nota_transf = value
        End Set
    End Property
    Public Property total_volume_max_compartimentos() As Decimal
        Get
            Return _total_volume_max_compartimentos
        End Get
        Set(ByVal value As Decimal)
            _total_volume_max_compartimentos = value
        End Set
    End Property
    Public Property dt_transmissao_ini() As String
        Get
            Return _dt_transmissao_ini
        End Get
        Set(ByVal value As String)
            _dt_transmissao_ini = value
        End Set
    End Property
    Public Property dt_transmissao_fim() As String
        Get
            Return _dt_transmissao_fim
        End Get
        Set(ByVal value As String)
            _dt_transmissao_fim = value
        End Set
    End Property
    Public Property dt_transmissao() As String
        Get
            Return _dt_transmissao
        End Get
        Set(ByVal value As String)
            _dt_transmissao = value
        End Set
    End Property
    Public Property nm_linha() As String
        Get
            Return _nm_linha
        End Get
        Set(ByVal value As String)
            _nm_linha = value
        End Set
    End Property
    Public Property path_arquivofrete() As String
        Get
            Return _path_arquivofrete
        End Get
        Set(ByVal value As String)
            _path_arquivofrete = value
        End Set
    End Property
    Public Property st_exportacao_frete() As String
        Get
            Return _st_exportacao_frete
        End Get
        Set(ByVal value As String)
            _st_exportacao_frete = value
        End Set
    End Property
    Public Property id_exportacao_frete_execucao() As Int32
        Get
            Return _id_exportacao_frete_execucao
        End Get
        Set(ByVal value As Int32)
            _id_exportacao_frete_execucao = value
        End Set
    End Property
    Public Property id_exportacao_frete_execucao_itens() As Int32
        Get
            Return _id_exportacao_frete_execucao_itens
        End Get
        Set(ByVal value As Int32)
            _id_exportacao_frete_execucao_itens = value
        End Set
    End Property
    Public Sub New()

    End Sub
    Public Sub New(ByVal id As Int32)

        Me._id_romaneio = id
        loadRomaneio()

    End Sub
 
    Public Function getRomaneioByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneio", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioNotaTransfByStatus() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioNotaTransf", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneiosComplementarByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneiosComplementar", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioMotoristaByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioMotoristas", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioControleLeite() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioControleLeite", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioAnaliseFisicoQuimica() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioAnaliseFisicoQuimica", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioAnaliseFisicoQuimicaComentarios() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioAnaliseFisicoQuimicaComentarios", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function

    Private Sub loadRomaneio()

        Dim dataSet As DataSet = getRomaneioByFilters()
        ParametersEngine.persistObjectValues(dataSet.Tables(0).Rows(0), Me)

    End Sub
    Private Sub reloadRomaneio()
        'limpar propriedades romaneio
        Me.id_romaneio_transbordo = 0
        Me.id_estabelecimento = 0
        Me.id_cooperativa = 0
        Me.cd_cooperativa = String.Empty
        Me.nm_cooperativa = String.Empty
        Me.id_transportador = 0
        Me.cd_transportador = String.Empty
        Me.nm_transportador = String.Empty
        Me.cd_cnh = String.Empty
        Me.nm_motorista = String.Empty
        Me.id_motorista = 0
        Me.ds_placa = String.Empty
        Me.id_linha = 0
        Me.ds_linha = String.Empty
        Me.dt_hora_entrada = String.Empty
        Me.dt_hora_entrada_ini = String.Empty
        Me.dt_hora_entrada_fim = String.Empty
        Me.dt_hora_saida = String.Empty
        Me.dt_pesagem_inicial = String.Empty
        Me.dt_pesagem_final = String.Empty
        Me.nr_tara = 0
        Me.nr_pesagem_inicial = 0
        Me.nr_pesagem_final = 0
        Me.nr_peso_liquido = 0
        Me.nr_peso_liquido_caderneta = 0
        Me.nr_peso_liquido_nota = 0
        Me.nr_nota_fiscal = String.Empty
        Me.nr_serie_nota_fiscal = String.Empty
        Me.nr_valor_nota_fiscal = 0
        Me.dt_saida_nota = String.Empty
        Me.id_item = 0
        Me.nm_item = String.Empty
        Me.nr_caderneta = 0
        Me.id_st_romaneio = 0
        Me.id_st_analise_global = 0
        Me.id_st_analise_compartimento = 0
        Me.id_st_analise_uproducao = 0
        Me.id_coleta_transmissao = 0
        Me.id_criacao = 0
        Me.id_modificador = 0
        Me.dt_criacao = String.Empty
        Me.dt_modificacao = String.Empty
        Me.ds_estabelecimento = String.Empty
        Me.ds_transportador = String.Empty
        Me.nm_st_romaneio = String.Empty
        Me.st_reanalise = String.Empty
        Me.nm_st_analise_compartimento = String.Empty
        Me.nm_st_analise_uproducao = String.Empty
        Me.data_inicio = String.Empty
        Me.data_fim = String.Empty
        Me.id_linha_ini = 0
        Me.id_linha_fim = 0
        Me.nr_peso_liquido_nota_transf = 0
        Me.nr_nota_fiscal_transf = String.Empty
        Me.nr_serie_nota_fiscal_transf = String.Empty
        Me.dt_emissao_nota_transf = String.Empty
        Me.st_romaneio_transbordo = String.Empty
        Me.total_volume_max_compartimentos = 0
        Me.dt_transmissao_ini = String.Empty
        Me.dt_transmissao_fim = String.Empty
        Me.dt_transmissao = String.Empty
        Me.nm_linha = String.Empty
        Me.ds_placa_frete = String.Empty
        Me.path_arquivofrete = String.Empty
        Me.st_exportacao_frete = String.Empty
        Me.id_exportacao_frete_execucao = 0
        Me.id_exportacao_frete_execucao_itens = 0

        Dim dataSet As DataSet = getRomaneioByFilters()
        ParametersEngine.persistObjectValues(dataSet.Tables(0).Rows(0), Me)

    End Sub


    Public Function insertRomaneio() As Int32

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_insertRomaneio", parameters, ExecuteType.Insert), Int32)

        End Using
    End Function
    Public Function abrirRomaneio()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Inclui romaneio
            Me.id_romaneio = CType(transacao.ExecuteScalar("ms_insertRomaneio", parameters, ExecuteType.Insert), Int32)
            parameters = ParametersEngine.getParametersFromObject(Me)
            'Pega os parametros para romaneio_compartimento
            Dim param_comp As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Insere romaneio compartimento
            transacao.Execute("ms_insertRomaneioCompartimento", param_comp, ExecuteType.Insert)

            'Insere romaneio compartimento unidade producao
            transacao.Execute("ms_insertRomaneioUProducao", param_comp, ExecuteType.Insert)

            'Insere romaneio placas
            transacao.Execute("ms_insertRomaneioPlacas", parameters, ExecuteType.Insert)
            'Atualiza a Placa Principal
            transacao.Execute("ms_updateAbrirRomaneioPlacaStPrincipal", parameters, ExecuteType.Update)

            'Insere Analise Compartimento
            transacao.Execute("ms_insertRomaneioAnaliseCompartimento", parameters, ExecuteType.Insert)

            'Insere romaneio mapa de leite
            'transacao.Execute("ms_insertRomaneioMapaLeite", param_comp, ExecuteType.Insert)

            'Insere romaneio analise global
            'transacao.Execute("ms_insertRomaneioAnaliseGlobal", param_comp, ExecuteType.Insert)

            'Comita
            transacao.Commit()
            transacao.Dispose()     ' 14/11/2008
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            transacao.Dispose()     ' 14/11/2008
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function abrirRomaneioCooperativa()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Inclui romaneio
            Me.id_romaneio = CType(transacao.ExecuteScalar("ms_insertRomaneioCooperativa", parameters, ExecuteType.Insert), Int32)

            parameters = ParametersEngine.getParametersFromObject(Me)
            Me.romaneio_compartimento = New Romaneio_Compartimento
            'Pega os parametros para romaneio_compartimento
            Me.romaneio_compartimento.id_romaneio = Me.id_romaneio
            Me.romaneio_compartimento.id_modificador = Me.id_modificador
            For i As Integer = 0 To rc_ds_placa.Count - 1
                Me.romaneio_compartimento.ds_placa = Me.rc_ds_placa(i).ToString
                Me.romaneio_compartimento.id_compartimento = Convert.ToInt32(Me.rc_id_compartimento(i))
                Me.romaneio_compartimento.nr_total_litros = Me.rc_nr_total_volume(i)
                'Pega os parametros para romaneio_compartimento
                Dim param_comp As List(Of Parameters) = ParametersEngine.getParametersFromObject(romaneio_compartimento)
                transacao.Execute("ms_insertRomaneioCompartimentoCooperativa", param_comp, ExecuteType.Insert)
            Next

            'Insere romaneio placas
            transacao.Execute("ms_insertRomaneioPlacas", parameters, ExecuteType.Insert)
            'Atualiza a Placa Principal
            transacao.Execute("ms_updateRomaneioPlacaStPrincipal", parameters, ExecuteType.Update)
            'Insere Analise Compartimento
            transacao.Execute("ms_insertRomaneioAnaliseCompartimento", parameters, ExecuteType.Insert)
            'Fran 30/09/2008 i - pesagem inicial na tela de cooperativa
            'atualiza o romaneio para status ABERTO pois j� informou dados de pesagem
            transacao.Execute("ms_updateRomaneio", parameters, ExecuteType.Update)


            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function abrirPreRomaneio()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Inclui romaneio
            Me.id_romaneio = CType(transacao.ExecuteScalar("ms_insertRomaneio", parameters, ExecuteType.Insert), Int32)
            parameters = ParametersEngine.getParametersFromObject(Me)
            'Pega os parametros para romaneio_compartimento
            Dim param_comp As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Insere romaneio compartimento
            transacao.Execute("ms_insertRomaneioCompartimento", param_comp, ExecuteType.Insert)

            'Insere romaneio compartimento unidade producao
            transacao.Execute("ms_insertRomaneioUProducao", param_comp, ExecuteType.Insert)

            'Insere romaneio placas
            transacao.Execute("ms_insertRomaneioPlacas", parameters, ExecuteType.Insert)
            'Atualiza a Placa Principal
            transacao.Execute("ms_updateAbrirRomaneioPlacaStPrincipal", parameters, ExecuteType.Update)
            'Pre romaneio
            Me.id_st_romaneio = 5
            parameters = ParametersEngine.getParametersFromObject(Me)

            transacao.Execute("ms_updateRomaneio", parameters, ExecuteType.Update)
            'Comita
            transacao.Commit()
            'Retorna ao id do romaneio
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function gerarRomaneioReanalises()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Atualiza todas as an�lise para reanalise = S, e limpa os status dastabelas de romaneio
            transacao.Execute("ms_updateRomaneioAnalisesReanalise", parameters, ExecuteType.Update)

            'Insere Analise Compartimento, como se estivesse iniciando processo
            transacao.Execute("ms_insertRomaneioAnaliseCompartimentoReanalise", parameters, ExecuteType.Insert)

            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Sub FecharRomaneio()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Atualizar romaneio
            transacao.Execute("ms_updateRomaneioFechar", parameters, ExecuteType.Update)
            'Atualizar pesagens
            transacao.Execute("ms_updateRomaneioPesagens", parameters, ExecuteType.Update)

            If Me.id_cooperativa > 0 Then
                'Insere romaneio mapa de leite
                transacao.Execute("ms_insertRomaneioMapaLeiteCooperativa", parameters, ExecuteType.Insert)

                'Insere romaneio mapa de leite
                transacao.Execute("ms_insertRomaneioMapaLeiteDescartadoCooperativa", parameters, ExecuteType.Insert)
            Else
                'Insere romaneio mapa de leite
                transacao.Execute("ms_insertRomaneioMapaLeite", parameters, ExecuteType.Insert)

                'Insere romaneio mapa de leite
                transacao.Execute("ms_insertRomaneioMapaLeiteDescartado", parameters, ExecuteType.Insert)
            End If

            If Me.st_romaneio_transbordo = "S" Then
                transacao.Execute("ms_updateRomaneioMapaLeiteTransbordo", parameters, ExecuteType.Update)
            End If

            'Fran 30/11/2008 i - Atualiza a coluna Rejeicao_antibiotico para 'S' para as analises de produtores rejeitadas por antibitorico
            transacao.Execute("ms_updateRomaneioMapaLeiteRejeicaoAntibiotico", parameters, ExecuteType.Update)


            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            'Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Sub
    Public Function registrarAnaliseGlobalPositiva()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para atualiza��o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Insere Analise Compartimento
            transacao.Execute("ms_insertRomaneioAnaliseCompartimento", parameters, ExecuteType.Insert)

            'Atualiza status da analise global no romaneio
            transacao.Execute("ms_updateRomaneioStatusAnaliseGlobal", parameters, ExecuteType.Update)


            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function registrarAnaliseCompartimentoRejeitada()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para atualiza��o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            Dim params As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me.romaneio_compartimento)

            'Atualiza status em Romaneio Compartimento
            transacao.Execute("ms_updateRomaneioCompartimento", params, ExecuteType.Update)


            'Atualiza status da analise compartimento no romaneio
            transacao.Execute("ms_updateRomaneioStatusAnaliseCompartimento", parameters, ExecuteType.Update)

            Dim romaneioanaliseuproducao As New RomaneioAnaliseUProducao
            romaneioanaliseuproducao.id_romaneio = Me.id_romaneio
            romaneioanaliseuproducao.id_romaneio_compartimento = Me.romaneio_compartimento.id_romaneio_compartimento

            'Dim dsanaliseuproducao As DataSet = romaneioanaliseuproducao.getRomaneioAnalisesUProducaoByFilters
            Dim dataSet As New DataSet
            transacao.Fill(dataSet, "ms_getRomaneioAnalisesUProducao", params, "ms_romaneio_analise_uproducao")

            If (dataSet.Tables(0).Rows.Count = 0) Then
                ''If Me.st_reanalise = "S" Then
                'Se n�o tem linhas cria as analises uproducao para o compartimento
                'Se � uma reanalise gera as linhas com a diferen�a que s� traz da an�lise as que estiverem com flag de reanalise
                ''transacao.Execute("ms_insertRomaneioAnaliseUProducaoReanalise", params, ExecuteType.Insert)
                ''Else
                'Se n�o tem linhas cria as analises uproducao para o compartimento
                transacao.Execute("ms_insertRomaneioAnaliseUProducao", params, ExecuteType.Insert)
                ''End If
            End If

            'Atualiza todos os compartimentos do romaneio com o nome do analista e a hora (nova tela)
            Me.romaneio_compartimento.id_romaneio_compartimento = 0
            params = ParametersEngine.getParametersFromObject(Me.romaneio_compartimento)
            transacao.Execute("ms_updateRomaneioCompartimentosAnalista", params, ExecuteType.Update)

                'Comita
                transacao.Commit()
                'Retorna ao id da propriedade
                Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function registrarAnaliseCompartimentoAprovada()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para atualiza��o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim params As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me.romaneio_compartimento)

            'Atualiza status em Romaneio Compartimento
            transacao.Execute("ms_updateRomaneioCompartimento", params, ExecuteType.Update)

            'Dim romaneiocompartimento As New Romaneio_Compartimento
            'romaneiocompartimento.id_romaneio = Me.id_romaneio
            'Pega todos os compartimentos rejeitados (status 3 ) e diferentes de nmulo
            'verifica se tem algum comp rejeitado
            Dim dataSet As New DataSet
            transacao.Fill(dataSet, "ms_getRomaneioCompartimentosSituacaoRejeitados", parameters, "ms_romaneio_compartimento")
            'se n�o tem ninguem rejeitado
            If (dataSet.Tables(0).Rows.Count = 0) Then
                'Atualiza status da analise compartimento no romaneio para aprovado
                'parameters.Find(
                transacao.Execute("ms_updateRomaneioStatusAnaliseCompartimento", parameters, ExecuteType.Update)

            End If

            'Atualiza todos os compartimentos do romaneio com o nome do analista e a hora (nova tela)
            Me.romaneio_compartimento.id_romaneio_compartimento = 0
            params = ParametersEngine.getParametersFromObject(Me.romaneio_compartimento)
            transacao.Execute("ms_updateRomaneioCompartimentosAnalista", params, ExecuteType.Update)

            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function

    Public Sub updateRomaneioStatusAnaliseGlobal()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioStatusAnaliseGlobal", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioStatusAnaliseCompartimento()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioStatusAnaliseCompartimento", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioStatusAnaliseUProducao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioStatusAnaliseUProducao", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneio()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneio", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioFechar()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioFechar", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioPesagens()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioPesagens", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioPesagemFinal()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioPesagemFinal", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Sub updateRomaneioSituacao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioSituacao", parameters, ExecuteType.Update)

        End Using

    End Sub
    Public Function getRomaneioAbertoEmAnaliseByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioAbertoEmAnalise", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioFecharEmAnaliseByFilters() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioFecharEmAnalise", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioReajuste() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioReajuste", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioAnalisesCompartimentosDistinct() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioAnalisesCompartimentosDistinct", parameters, "ms_romaneio_analise_compartimento")
            Return dataSet

        End Using

    End Function
    Public Function getRomaneioAnalisesNullNavegacao() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getRomaneioAnalisesNullNavegacao", parameters, "ms_romaneio_analise_compartimento")
            Return dataSet

        End Using

    End Function

    Public Function getRomaneioCompartimentoMediaDens() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioCompartimentoMediaDens", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function getRomaneioCompartimentosSomaVolumeRejeitadobyRomaneio() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioCompartimentosSomaVolumeRejeitadobyRomaneio", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function getRomaneioCompartimentosSomaVolumeAjustadobyRomaneio() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioCompartimentosSomaVolumeAjustadobyRomaneio", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function getRomaneioCompartimentosSomaVolumebyRomaneio() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioCompartimentosSomaVolumebyRomaneio", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function

    Public Function getRomaneioSomaCadernetasbyNotaTransf() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioSomaCadernetasbyNotaTransf", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function abrirRomaneioTransbordo()

        Dim transacao As New DataAccess
        'Inicia Transa��o
        transacao.StartTransaction(IsolationLevel.RepeatableRead)
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            'Inclui romaneio
            Me.id_romaneio = CType(transacao.ExecuteScalar("ms_insertRomaneioTransbordo", parameters, ExecuteType.Insert), Int32)
            Me.id_romaneio_transbordo = Me.id_romaneio
            parameters = ParametersEngine.getParametersFromObject(Me)
            'Atualiza os pre romaneios da nota para status
            transacao.Execute("ms_updateRomaneioPre", parameters, ExecuteType.Update)

            Me.romaneio_compartimento = New Romaneio_Compartimento
            'Pega os parametros para romaneio_compartimento
            Me.romaneio_compartimento.id_romaneio = Me.id_romaneio
            Me.romaneio_compartimento.id_modificador = Me.id_modificador
            For i As Integer = 0 To rc_ds_placa.Count - 1
                Me.romaneio_compartimento.ds_placa = Me.rc_ds_placa(i).ToString
                Me.romaneio_compartimento.id_compartimento = Convert.ToInt32(Me.rc_id_compartimento(i))
                Me.romaneio_compartimento.nr_total_litros = Me.rc_nr_total_volume(i)
                'Pega os parametros para romaneio_compartimento
                Dim param_comp As List(Of Parameters) = ParametersEngine.getParametersFromObject(romaneio_compartimento)
                transacao.Execute("ms_insertRomaneioCompartimentoCooperativa", param_comp, ExecuteType.Insert)
            Next

            'Insere romaneio placas
            transacao.Execute("ms_insertRomaneioPlacas", parameters, ExecuteType.Insert)
            'Atualiza a Placa Principal
            transacao.Execute("ms_updateRomaneioPlacaStPrincipal", parameters, ExecuteType.Update)
            'Insere Analise Compartimento
            transacao.Execute("ms_insertRomaneioAnaliseCompartimento", parameters, ExecuteType.Insert)
            'Fran 30/09/2008 i - pesagem inicial na tela de cooperativa
            'atualiza o romaneio para status ABERTO pois j� informou dados de pesagem
            transacao.Execute("ms_updateRomaneio", parameters, ExecuteType.Update)

            transacao.Execute("ms_insertRomaneioUProducaoTransbordo", parameters, ExecuteType.Insert)

            'Comita
            transacao.Commit()
            'Retorna ao id da propriedade
            Return Me.id_romaneio
        Catch err As Exception
            transacao.RollBack()
            Throw New Exception(err.Message)
        End Try
    End Function
    Public Function FecharRomaneioConsistir() As Boolean

        Dim isvalid As Boolean = True
        FecharRomaneioConsistir = True
        Try
            'Pega os parametros para inclus�o romaneio
            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)

            If exc_AnaliseObrigatoriaCompartimentoNula(Me.id_romaneio) = False Then
                FecharRomaneioConsistir = False
                isvalid = False
                Throw New Exception("H� an�lises obrigat�rias de Compartimentos sem preenchimento de resultado. O Romaneio n�o pode ser fechado enquanto o registro de an�lises n�o for conclu�do.")
            End If

            If isvalid = True Then
                If exc_AnaliseObrigatoriaUproducaoNula(Me.id_romaneio) = False Then
                    FecharRomaneioConsistir = False
                    isvalid = False
                    Throw New Exception("H� an�lises obrigat�rias de Unidades de Produ��o/Produtores sem preenchimento de resultado. O Romaneio n�o pode ser fechado enquanto o registro de an�lises n�o for conclu�do.")
                End If
            End If
            'If isvalid = True Then
            'If exc_LacresSaidaNulo(Me.id_romaneio) = False Then
            'isvalid = False
            'Throw New Exception("Para fechar o romaneio todos os lacres de sa�da devem ser informados no menu 'Registros Finais'.")
            'End If
            'End If
            If isvalid = True Then
                If exc_RegistrosFinaisNulo(Me.id_romaneio) = False Then
                    FecharRomaneioConsistir = False
                    isvalid = False
                    Throw New Exception("Para fechar o romaneio todas as informa��es das placas no menu 'Registros Finais' devem ser preenchidas.")
                End If
            End If

        Catch err As Exception
            Throw New Exception(err.Message)
        End Try
    End Function

    Public Function exc_AnaliseObrigatoriaUproducaoNula(ByVal id_romaneio As Int32) As Boolean
        Try
            Dim isvalid As Boolean = True

            Dim analisesup As New RomaneioAnaliseUProducao
            analisesup.id_romaneio = id_romaneio
            If analisesup.getRomaneioAnaliseUProducaoSemResultado > 0 Then
                isvalid = False
            End If

            exc_AnaliseObrigatoriaUproducaoNula = isvalid

        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    
    Public Function exc_AnaliseObrigatoriaCompartimentoNula(ByVal id_romaneio As Int32) As Boolean
        Try
            Dim isvalid As Boolean = True

            Dim analisescomp As New RomaneioAnaliseCompartimento
            analisescomp.id_romaneio = id_romaneio
            If analisescomp.getRomaneioAnaliseCompartimentoSemResultado > 0 Then
                isvalid = False
            End If

            exc_AnaliseObrigatoriaCompartimentoNula = isvalid

        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function exc_RegistrosFinaisNulo(ByVal id_romaneio As Int32) As Boolean
        Try
            'Verifica se o romaneio placa foi preenchido pela coluna dt_ini_descarga
            Dim isvalid As Boolean = True

            Dim placas As New RomaneioPlaca

            placas.id_romaneio = id_romaneio
            If placas.getRomaneioPlacasNulasByRomaneio > 0 Then
                isvalid = False
            End If

            exc_RegistrosFinaisNulo = isvalid

        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function
    Public Function exc_LacresSaidaNulo(ByVal id_romaneio As Int32) As Boolean
        Try
            'Verifica se os lacres de s�da foram preenchidos
            Dim isvalid As Boolean = True

            Dim lacres As New RomaneioLacre

            lacres.id_romaneio = id_romaneio
            If lacres.getRomaneioLacresSaidaNulosByRomaneio > 0 Then
                isvalid = False
            End If

            exc_LacresSaidaNulo = isvalid

        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function getRomaneioSomaControleLeitebyDia() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getRomaneioControleLeiteSomabyDia", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function getFreteRomaneioByTransportadora() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getFreteRomaneioByTransportadora", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function
    Public Function getFreteSomaKm() As Decimal
        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Return CType(data.ExecuteScalar("ms_getFreteSomaKm", parameters, ExecuteType.Select), Decimal)

        End Using

    End Function
    Public Function getFreteColetas() As DataSet

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            Dim dataSet As New DataSet

            data.Fill(dataSet, "ms_getFreteColetas", parameters, "ms_romaneio")
            Return dataSet

        End Using

    End Function

    'fran 22/09/2009 i rls21 - GKO
    Private Function Frete_Registro_000() As String


        Try

            Dim linhatexto As String

            ' Registro 000
            Dim tp_registro As String   'Num 3 posi��es
            Dim num_interface As String 'alfnum 10 posi��es
            Dim versao As String        'alfnum 6 posi��es
            Dim remetente As String     'alfnum 40 posi��es
            Dim destinatario As String  'alfnum 40 posi��es
            Dim cd_ambiente As String   'alfnum 3 posi��es


            '====================================================================================
            ' Registro Tipo 000
            '====================================================================================

            'Tipo de Registro - Fixo 000
            tp_registro = "000"

            'Num Interface - Fixo INTDNE - 10 posi��es
            num_interface = String.Concat("INTDNE", Space(4))

            'Versao - Fixo 5.71a - 6 posi��es
            versao = String.Concat("5.71a", Space(1))

            'remetente - Fixo DANONE LTDA - 40 posi��es
            remetente = "DANONE LTDA"
            remetente = String.Concat(remetente, Space(40 - Len(remetente)))

            'destinatario - Fixo DANONE LTDA - 40 posi��es
            destinatario = "DANONE LTDA"
            destinatario = String.Concat(destinatario, Space(40 - Len(destinatario)))

            'cod ambiente - Fixo BRANCO - 3 posi��es
            cd_ambiente = Space(3)

            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            linhatexto = tp_registro + num_interface + versao + remetente
            linhatexto = linhatexto + destinatario + cd_ambiente

            Frete_Registro_000 = linhatexto

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function

    'fran 22/09/2009 i rls21 - GKO
    Private Function Frete_Registro_060(ByVal pCNPJEstabel As String, ByVal pCdEstabel As String, ByVal pCidadeEstabel As String, ByVal pUFEstabel As String, ByVal pCNPJTransportadora As String, ByVal pPlaca_Frete As String, ByVal pnmEquipamento As String, Optional ByVal pnmCidadeMaiorDistancia As String = "", Optional ByVal pcdUFMaiorDistancia As String = "") As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim floperacao As String   'alfnum 1 posi��es
            Dim cdromaneio As String   'alfnum 10 posi��es
            Dim chaverespfrete As String 'alfnum 15 posi��es
            Dim dtembarque As String   'data 10 posi��es
            Dim hrembarque As String   'num 4 posi��es
            Dim cdtransportadora As String 'alfnum 15 posicoes
            Dim cdremessa As String    'alfanum 12 posicoes
            Dim cdZonaMaiorDistancia As String  'alfanum 8 posicoes
            Dim nmCidMaiorDistancia As String   'alfanum 30 posicoes
            Dim cdUFMaiorDistancia As String    'alfanum 2 posicoes
            Dim vrtotalpeso As String         'num 15 posicoes
            Dim vrtotalkm As String           'num 5 posicoes
            Dim cdequipamento As String        'alfanum 10 posicoes
            Dim dsplacaveiculo As String       'alfanum 10 posicoes
            Dim nmmotorista As String          'alfanum 40 posicoes
            Dim txobs As String                'alfanum 80 posicoes
            Dim tpviagem As String
            Dim stexcluirefextromaneio As String
            Dim lpos As Integer
            Dim lvalorint As String
            Dim lvalordec As String
            '====================================================================================
            ' Registro Tipo 060
            '====================================================================================

            'Tipo de Registro - Fixo 060
            tpregistro = "060"

            'Fl Operacao - Fixo A - 1 posi��o
            floperacao = "A"

            'C�d Romaneio - 10 posi��es
            'Fran 16/10/2009 i  chamado 477
            'cdromaneio = Me.id_romaneio.ToString.Trim
            'If Len(cdromaneio) > 10 Then
            'cdromaneio = Left(cdromaneio, 10)
            'Else
            'cdromaneio = String.Concat(cdromaneio, Space(Len(cdromaneio)))
            'End If
            If Me.id_cooperativa > 0 Then
                cdromaneio = String.Concat("C", Left(Me.id_romaneio.ToString.Trim, 9))
            Else
                cdromaneio = String.Concat("D", Left(Me.id_romaneio.ToString.Trim, 9))
            End If
            If Len(cdromaneio) > 10 Then
                cdromaneio = Left(cdromaneio, 10)
            Else
                cdromaneio = String.Concat(cdromaneio, Space(10 - Len(cdromaneio)))
            End If
            'Fran 16/10/2009 f

            'chave resp frete - CNPJ do estabelecimento do romaneio - 15 posi��es
            chaverespfrete = FormataCampo(pCNPJEstabel.Trim.ToString).Trim
            chaverespfrete = String.Concat(chaverespfrete, Space(15 - Len(chaverespfrete)))

            'data de embarque - dt abertura do romaneio 10 posi��es
            dtembarque = Left(Me.dt_hora_entrada, 10).ToString

            'hora de embarque - Fixo 0000 4 posi��es
            hrembarque = "0000"

            'cd transportadora - CNPJ Transportadora - 15 posi��es
            cdtransportadora = FormataCampo(pCNPJTransportadora.Trim.ToString).Trim
            cdtransportadora = String.Concat(cdtransportadora, Space(15 - Len(cdtransportadora)))

            'cd remessa - Nr_caderneta + Cd Estabelecimento ou Nr Nota Fiscal + '-COOP' para Cooperativa - 15 posi��es

            If Me.id_cooperativa > 0 Then
                'cdremessa = String.Concat(Me.nr_nota_fiscal.ToString, "-COOP") 'Fran 19/10/2009 chamado 477
                cdremessa = Me.nr_nota_fiscal.ToString.Trim 'Fran 19/10/2009 chamado 477
            Else
                'cdremessa = String.Concat(Me.nr_caderneta.ToString, "-", pCdEstabel.ToString) 'Fran 19/10/2009 chamado 477
                cdremessa = Me.nr_caderneta.ToString.Trim 'Fran 19/10/2009 chamado 477
            End If
            If Len(cdremessa) > 12 Then
                cdremessa = Left(cdremessa, 12)
            Else
                cdremessa = String.Concat(cdremessa, Space(12 - Len(cdremessa)))
            End If

            'cod zona - Fixo BRANCO - 10 posi��es
            cdZonaMaiorDistancia = Space(10) 'alterada de 8 para 10 posi��es chamado 475

            'Nm cidade - 30 posi��es
            'UF - 2 posi��es
            If Me.id_cooperativa > 0 Then 'Pega o nm dos dados de cooperativa 
                Dim coop As New Pessoa(Me.id_cooperativa)
                If coop.nm_cidade Is Nothing Then
                    coop.nm_cidade = String.Empty
                End If
                If coop.cd_uf Is Nothing Then
                    coop.cd_uf = String.Empty
                End If
                nmCidMaiorDistancia = Left(coop.nm_cidade.Trim, 30)
                cdUFMaiorDistancia = Left(coop.cd_uf.Trim, 2)
                vrtotalpeso = Me.nr_peso_liquido_nota
            Else
                'fran 26/10/2009 i utilizar a cidade e estado do primeiro produtor
                'nmCidMaiorDistancia = Left(pCidadeEstabel, 30)
                'cdUFMaiorDistancia = Left(pUFEstabel, 2)
                nmCidMaiorDistancia = Left(pnmCidadeMaiorDistancia, 30)
                cdUFMaiorDistancia = Left(pcdUFMaiorDistancia, 2)
                'fran 26/10/2009 f
                vrtotalpeso = Me.nr_peso_liquido_caderneta.ToString
            End If
            nmCidMaiorDistancia = String.Concat(nmCidMaiorDistancia, Space(30 - Len(nmCidMaiorDistancia)))
            cdUFMaiorDistancia = String.Concat(cdUFMaiorDistancia, Space(2 - Len(cdUFMaiorDistancia)))

            ' 13 inteiros, sem virgula  e 2 decimais (15 caracteres)
            lpos = InStr(1, vrtotalpeso, ",")
            If lpos = 0 Then   ' Se n�o tem casas decimais
                vrtotalpeso = Right(String.Concat(StrDup(13 - Len(vrtotalpeso.Trim), "0"), vrtotalpeso), 13)
                vrtotalpeso = String.Concat(vrtotalpeso, "00")
            Else
                lvalorint = CStr(Left(vrtotalpeso, lpos - 1))  ' Pegar somente o valor inteiro
                lvalorint = Right(String.Concat(StrDup(13 - Len(lvalorint.Trim), "0"), lvalorint), 13)
                lvalordec = CStr(Mid(CStr(vrtotalpeso), lpos + 1))  ' Pegar somente o valor decimal
                If Len(lvalordec) >= 2 Then
                    lvalordec = Left(lvalordec, 2)
                Else
                    lvalordec = Left(String.Concat(lvalordec, StrDup(2 - Len(lvalordec), "0")), 2)
                End If

                vrtotalpeso = String.Concat(lvalorint, lvalordec)
            End If

            'valor total km - somatoria de toda km incluido n�o coleta com motivos permitidos
            If Me.id_cooperativa > 0 Then 'gera total de km zerado pois GKO tratara
                vrtotalkm = "00000"
            Else 'se caderneta
                Me.ds_placa_frete = pPlaca_Frete.Trim
                ' 5 inteiros
                vrtotalkm = CLng(Me.getFreteSomaKm).ToString
                vrtotalkm = Right(String.Concat(StrDup(5 - Len(vrtotalkm.Trim), "0"), vrtotalkm), 6)
            End If

            'Cd equipamento 10 posi�oes
            'cdequipamento = pcdEquipamento.Trim 'fran 19/10/2009 i
            cdequipamento = pnmEquipamento 'fran 19/10/2009 i
            If Len(cdequipamento) > 10 Then
                cdequipamento = Left(cdequipamento, 10)
            Else
                cdequipamento = String.Concat(cdequipamento, Space(10 - Len(cdequipamento)))
            End If


            'Placa 10 posi��es
            dsplacaveiculo = pPlaca_Frete.Trim
            dsplacaveiculo = String.Concat(dsplacaveiculo, Space(10 - Len(dsplacaveiculo)))

            'Motorista 40 posi��es
            nmmotorista = pPlaca_Frete.Trim
            nmmotorista = String.Concat(nmmotorista, Space(40 - Len(nmmotorista)))

            txobs = Space(80)
            tpviagem = "1"
            stexcluirefextromaneio = "0"

            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            linhatexto = tpregistro + floperacao + cdromaneio + chaverespfrete + dtembarque + hrembarque
            linhatexto = linhatexto + cdtransportadora + cdremessa + cdZonaMaiorDistancia + nmCidMaiorDistancia
            linhatexto = linhatexto + cdUFMaiorDistancia + vrtotalpeso + vrtotalkm + cdequipamento
            linhatexto = linhatexto + dsplacaveiculo + nmmotorista + txobs + tpviagem + stexcluirefextromaneio

            Frete_Registro_060 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function
    'fran 22/09/2009 i rls21 - GKO
    Private Function Frete_Registro_100(Optional ByVal pEstabeldoRomaneio As DataRow = Nothing, Optional ByVal pDadosCooperativa As DataRow = Nothing, Optional ByVal pDadosProdutor As DataRow = Nothing) As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim floperacao As String   'alfnum 1 posi��es
            Dim nrcnpjcpf As String
            Dim tpparceirocomercial As String
            Dim cdparceirocoml As String
            Dim nmparceirocoml As String
            Dim dsendereco As String
            Dim dsbairro As String
            Dim nomecidade As String
            Dim uf As String
            Dim cep As String
            Dim cdzonatransporte As String
            Dim tppessoa As String
            Dim dsinscrmunicipal As String
            Dim dsinscrestadual As String
            Dim stcontribuinteicms As String
            Dim stregcredicms As String
            Dim stexcluirefextparcom As String

            Dim lpos As Integer
            Dim lvalorint As String
            Dim lvalordec As String
            '====================================================================================
            ' Registro Tipo 100
            '====================================================================================

            'Tipo de Registro - Fixo 100
            tpregistro = "100"

            'Fl Operacao - Fixo A - 1 posi��o
            floperacao = "A"

            If Me.id_cooperativa > 0 Then
                nrcnpjcpf = FormataCampo(pDadosCooperativa.Item("cd_cnpj").ToString.Trim)
                cdparceirocoml = nrcnpjcpf
                nmparceirocoml = pDadosCooperativa.Item("nm_pessoa").ToString.Trim
                dsendereco = String.Concat(pDadosCooperativa.Item("ds_endereco").ToString.Trim, Space(1), pDadosCooperativa.Item("nr_endereco").ToString.Trim)
                dsbairro = pDadosCooperativa.Item("ds_bairro").ToString.Trim
                nomecidade = pDadosCooperativa.Item("nm_cidade").ToString.Trim
                uf = pDadosCooperativa.Item("cd_uf").ToString.Trim
                cep = FormataCampo(pDadosCooperativa.Item("cd_cep").ToString.Trim)
                dsinscrestadual = FormataCampo(pDadosCooperativa.Item("cd_inscricao_estadual").ToString.Trim)
            Else
                'fran 17/12/2009 i chamado 477
                'nrcnpjcpf = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)
                'cdparceirocoml = Left(nrcnpjcpf, 14).ToString
                'nmparceirocoml = String.Concat("Danone Ltda", Space(1), pEstabeldoRomaneio.Item("nm_estabelecimento").ToString.Trim)
                'dsendereco = String.Concat(pEstabeldoRomaneio.Item("ds_endereco").ToString.Trim, Space(1), pEstabeldoRomaneio.Item("nr_endereco").ToString.Trim)
                'dsbairro = pEstabeldoRomaneio.Item("ds_bairro").ToString.Trim
                'nomecidade = pEstabeldoRomaneio.Item("nm_cidade").ToString.Trim
                'uf = pEstabeldoRomaneio.Item("cd_uf").ToString.Trim
                'cep = FormataCampo(pEstabeldoRomaneio.Item("cd_cep").ToString.Trim)
                'dsinscrestadual = FormataCampo(pEstabeldoRomaneio.Item("cd_inscricao_estadual").ToString.Trim)
                If Not pDadosProdutor.Item("cd_cpf").ToString.Trim.Equals(String.Empty) Then
                    nrcnpjcpf = FormataCampo(pDadosProdutor.Item("cd_cpf").ToString.Trim)
                Else
                    nrcnpjcpf = FormataCampo(pDadosProdutor.Item("cd_cnpj").ToString.Trim)
                End If
                cdparceirocoml = Left(nrcnpjcpf, 14).ToString
                nmparceirocoml = pDadosProdutor.Item("nm_pessoa").ToString.Trim
                dsendereco = String.Concat(pDadosProdutor.Item("ds_endereco").ToString.Trim, Space(1), pDadosProdutor.Item("nr_endereco").ToString.Trim)
                dsbairro = pDadosProdutor.Item("ds_bairro").ToString.Trim
                nomecidade = pDadosProdutor.Item("nm_cidade").ToString.Trim
                uf = pDadosProdutor.Item("cd_uf").ToString.Trim
                cep = FormataCampo(pDadosProdutor.Item("cd_cep").ToString.Trim)
                dsinscrestadual = FormataCampo(pDadosProdutor.Item("cd_inscricao_estadual").ToString.Trim)
                'fran 17/10/2009 f
            End If

            'Formata campos
            nrcnpjcpf = Right(String.Concat(StrDup(15 - Len(nrcnpjcpf), "0"), nrcnpjcpf), 15)
            cdparceirocoml = Left(String.Concat(cdparceirocoml, Space(14 - Len(cdparceirocoml))), 14)
            nmparceirocoml = Left(String.Concat(nmparceirocoml, Space(40 - Len(nmparceirocoml))), 40)
            dsendereco = Left(String.Concat(dsendereco, Space(50 - Len(dsendereco))), 50)
            dsbairro = Left(String.Concat(dsbairro, Space(20 - Len(dsbairro))), 20)
            nomecidade = Left(String.Concat(nomecidade, Space(30 - Len(nomecidade))), 30)
            uf = Left(String.Concat(uf, Space(2 - Len(uf))), 2)
            cep = Right(String.Concat(StrDup(8 - Len(cep), "0"), cep), 8)
            dsinscrestadual = Left(String.Concat(dsinscrestadual, Space(15 - Len(dsinscrestadual))), 15)

            'TpParcComls fixo 
            'Fran 16/10/2009 i chamado 477
            'tpparceirocomercial = "2"
            tpparceirocomercial = "3"
            'fran 16/10/2009 f
            'cdzonatransporte 10 posi��es
            cdzonatransporte = Space(10)
            'Tp Pessoa 2 posi��es
            'Fran 16/10/2009 i chamado 477
            'tppessoa = "2"
            tppessoa = "3"
            'Fran 16/10/2009 f
            'Inscr Municipal 15 posi��es
            dsinscrmunicipal = Space(15)
            stcontribuinteicms = "1"
            stregcredicms = "0"
            stexcluirefextparcom = Space(1)

            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            linhatexto = tpregistro + floperacao + nrcnpjcpf + tpparceirocomercial + cdparceirocoml + nmparceirocoml
            linhatexto = linhatexto + dsendereco + dsbairro + nomecidade + uf + cep
            linhatexto = linhatexto + cdzonatransporte + tppessoa + dsinscrmunicipal + dsinscrestadual
            linhatexto = linhatexto + stcontribuinteicms + stregcredicms + stexcluirefextparcom

            Frete_Registro_100 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function
    'fran 22/09/2009 i rls21 - GKO
    Private Function Frete_Registro_140(ByVal pCNPJTransportadora As String, ByVal pnmequipamento As String, Optional ByVal pId_coleta As String = "0", Optional ByVal pcoletaNprogramada As String = "N", Optional ByVal pEstabeldoRomaneio As DataRow = Nothing, Optional ByVal pDadosCooperativa As DataRow = Nothing, Optional ByVal pDadosProdutor As DataRow = Nothing, Optional ByVal pDadosPropriedade As DataRow = Nothing) As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim floperacao As String   'alfnum 1 posi��es
            Dim tpdocumento As String
            Dim parceirocomercial As String
            Dim cdnota As String
            Dim cdserie As String
            Dim dtemissao As String
            Dim dtembarque As String
            Dim tpentradasaida As String
            Dim pardestremet As String
            Dim dsenderecodestremet As String
            Dim dsbairrodestremet As String
            Dim nomecidade As String
            Dim uf As String
            Dim nrcepdestremet As String
            Dim cdzonatransporte As String
            Dim cddocnegfrete As String
            Dim cdtiponota As String
            Dim cdequipamento As String
            Dim cdembalagem As String
            Dim cdmeiotransporte As String
            Dim cdterritorio As String
            Dim dsseparadorconhecimento As String
            Dim dslote As String
            Dim cdromaneio As String
            Dim cdtransportadora As String
            Dim tpfrete As String
            Dim cddoctovinculado As String
            Dim cdseriedoctovinculado As String
            Dim cdnaturezaoperacao As String
            Dim stisentoimposto As String
            Dim stcreditoicms As String
            Dim stitemsubtribnacompra As String
            Dim tpfinalidadeoperacao As String
            Dim cdindfinanceiro As String
            Dim stentregaurgente As String
            Dim stfretediferenciado As String
            Dim dtentrega As String
            Dim chaverespfrete As String
            Dim dttabpreco As String
            Dim dtprevisaoentrega As String
            Dim stexcluiitemdne As String
            Dim stexcluirefext As String
            Dim vrfretepgcliente As String

            Dim lpos As Integer
            Dim lvalorint As String
            Dim lvalordec As String
            '====================================================================================
            ' Registro Tipo 140
            '====================================================================================

            'Tipo de Registro - Fixo 140
            tpregistro = "140"

            'Fl Operacao - Fixo A - 1 posi��o
            floperacao = "A"

            tpdocumento = "1"

            If Me.id_cooperativa > 0 Then
                parceirocomercial = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)
                cdnota = Left(String.Concat(Me.nr_nota_fiscal, Space(12 - Len(Me.nr_nota_fiscal))), 12)
                cdserie = Left(String.Concat(Me.nr_serie_nota_fiscal, Space(3 - Len(Me.nr_serie_nota_fiscal))), 3)
                dtemissao = DateTime.Parse(Me.dt_saida_nota).ToString("dd/MM/yyyy")
                dtembarque = DateTime.Parse(Me.dt_saida_nota).ToString("dd/MM/yyyy")
                tpentradasaida = "1"
                pardestremet = FormataCampo(pDadosCooperativa.Item("cd_cnpj").ToString.Trim)
                dsenderecodestremet = String.Concat(pDadosCooperativa.Item("ds_endereco").ToString.Trim, Space(1), pDadosCooperativa.Item("nr_endereco").ToString.Trim)
                dsbairrodestremet = pDadosCooperativa.Item("ds_bairro").ToString.Trim
                nomecidade = pDadosCooperativa.Item("nm_cidade").ToString.Trim
                uf = pDadosCooperativa.Item("cd_uf").ToString.Trim
                nrcepdestremet = FormataCampo(pDadosCooperativa.Item("cd_cep").ToString.Trim)
                dtentrega = DateTime.Parse(Me.dt_saida_nota).ToString("dd/MM/yyyy")
                chaverespfrete = pardestremet
            Else
                parceirocomercial = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)
                cdnota = Left(String.Concat(pId_coleta, Space(12 - Len(pId_coleta))), 12)
                'fran 18/10/2009 i chamado 477
                'cdserie = Space(3)
                'dtemissao = DateTime.Parse(Me.dt_hora_entrada).ToString("dd/MM/yyyy")
                'dtembarque = DateTime.Parse(Me.dt_hora_entrada).ToString("dd/MM/yyyy")
                'tpentradasaida = "1"
                'pardestremet = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)
                'dsenderecodestremet = String.Concat(pEstabeldoRomaneio.Item("ds_endereco").ToString.Trim, Space(1), pEstabeldoRomaneio.Item("nr_endereco").ToString.Trim)
                'dsbairrodestremet = pEstabeldoRomaneio.Item("ds_bairro").ToString.Trim
                'nomecidade = pEstabeldoRomaneio.Item("nm_cidade").ToString.Trim
                'uf = pEstabeldoRomaneio.Item("cd_uf").ToString.Trim
                'nrcepdestremet = FormataCampo(pEstabeldoRomaneio.Item("cd_cep").ToString.Trim)
                'dtentrega = DateTime.Parse(Me.dt_hora_entrada).ToString("dd/MM/yyyy")
                'chaverespfrete = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)
                cdserie = "DAL"
                dtemissao = DateTime.Parse(Me.dt_transmissao).ToString("dd/MM/yyyy")
                dtembarque = DateTime.Parse(Me.dt_hora_entrada).ToString("dd/MM/yyyy")
                tpentradasaida = "1"
                'pardestremet = FormataCampo(pDadosProdutor.Item("cd_cpf").ToString.Trim)
                If Not pDadosProdutor.Item("cd_cpf").ToString.Trim.Equals(String.Empty) Then
                    pardestremet = FormataCampo(pDadosProdutor.Item("cd_cpf").ToString.Trim)
                Else
                    pardestremet = FormataCampo(pDadosProdutor.Item("cd_cnpj").ToString.Trim)
                End If

                dsenderecodestremet = String.Concat(pDadosPropriedade.Item("id_propriedade").ToString.Trim, pDadosPropriedade.Item("nm_propriedade").ToString.Trim)
                dsbairrodestremet = dsenderecodestremet
                nomecidade = pDadosPropriedade.Item("nm_cidade").ToString.Trim
                uf = pDadosPropriedade.Item("cd_uf").ToString.Trim
                nrcepdestremet = FormataCampo(pDadosPropriedade.Item("cd_cep").ToString.Trim)
                dtentrega = DateTime.Parse(Me.dt_hora_entrada).ToString("dd/MM/yyyy")
                chaverespfrete = FormataCampo(pEstabeldoRomaneio.Item("cd_cnpj").ToString.Trim)

            End If

            'Formata campos
            parceirocomercial = Left(String.Concat(parceirocomercial, Space(15 - Len(parceirocomercial))), 15)
            pardestremet = Left(String.Concat(pardestremet, Space(15 - Len(pardestremet))), 15)

            If Len(dtemissao.Trim) > 10 Then
                dtemissao = Left(dtemissao, 10)
            Else
                dtemissao = Left(String.Concat(dtemissao, Space(10 - Len(dtemissao))), 10)
            End If
            If Len(dtembarque.Trim) > 10 Then
                dtembarque = Left(dtembarque, 10)
            Else
                dtembarque = Left(String.Concat(dtembarque, Space(10 - Len(dtembarque))), 10)
            End If
            If Len(dtentrega.Trim) > 10 Then
                dtentrega = Left(dtentrega, 10)
            Else
                dtentrega = Left(String.Concat(dtentrega, Space(10 - Len(dtentrega))), 10)
            End If
            If Len(dsenderecodestremet) > 50 Then
                dsenderecodestremet = Left(dsenderecodestremet, 50)
            Else
                dsenderecodestremet = Left(String.Concat(dsenderecodestremet, Space(50 - Len(dsenderecodestremet))), 50)
            End If
            If Len(dsbairrodestremet) > 20 Then
                dsbairrodestremet = Left(dsbairrodestremet, 20)
            Else
                dsbairrodestremet = Left(String.Concat(dsbairrodestremet, Space(20 - Len(dsbairrodestremet))), 20)
            End If
            nomecidade = Left(String.Concat(nomecidade, Space(30 - Len(nomecidade))), 30)
            uf = Left(String.Concat(uf, Space(2 - Len(uf))), 2)
            nrcepdestremet = Right(String.Concat(StrDup(8 - Len(nrcepdestremet), "0"), nrcepdestremet), 8)
            chaverespfrete = Left(String.Concat(chaverespfrete, Space(15 - Len(chaverespfrete))), 15)

            'cdzonatransporte 10 posi��es
            cdzonatransporte = Space(10)

            cddocnegfrete = Space(12)
            'fran 18/10/2009 chamado 477
            'cdtiponota = "TRAN"
            cdtiponota = "COMP"
            'fran 18/10/2009 f
            'Cd equipamento 10 posi�oes
            cdequipamento = pnmequipamento.Trim
            If Len(cdequipamento) > 10 Then
                cdequipamento = Left(cdequipamento, 10)
            Else
                cdequipamento = Left(String.Concat(cdequipamento, Space(10 - Len(cdequipamento))), 10)
            End If

            cdembalagem = (Space(4))
            'fran 18/10/2009 chamado 477
            'cdmeiotransporte = String.Concat("1", Space(3))
            cdmeiotransporte = String.Concat("4", Space(3))
            'fran 18/10/2009 f
            cdterritorio = Space(10)
            dsseparadorconhecimento = Space(10)
            'fran 18/10/2009 chamado 477
            'dslote = Space(20)
            'Fran 26/10/2009 i
            'dslote = String.Concat(Me.ds_placa_frete.ToString.Trim, Me.dt_transmissao).Trim
            dslote = String.Concat(Me.ds_placa_frete.ToString.Trim, DateTime.Parse(Me.dt_transmissao).ToString("dd/MM/yyyy")).Trim
            'Fran 26/10/2009 f

            If Len(dslote) > 20 Then
                dslote = Left(dslote, 20)
            Else
                dslote = Left(String.Concat(dslote, Space(20 - Len(dslote))), 20)
            End If
            'fran 18/10/2009 f

            'fran 18/20/2009 i chamado 477
            'If Len(Me.id_romaneio.ToString.Trim) > 10 Then
            '    cdromaneio = Left(Me.id_romaneio.ToString.Trim, 10)
            'Else
            '    cdromaneio = Left(String.Concat(Me.id_romaneio.ToString.Trim, Space(10 - Len(Me.id_romaneio.ToString.Trim))), 10)
            'End If
            If Me.id_cooperativa > 0 Then
                cdromaneio = String.Concat("C", Me.id_romaneio.ToString.Trim)
            Else
                cdromaneio = String.Concat("D", Me.id_romaneio.ToString.Trim)
            End If
            If Len(cdromaneio) > 10 Then
                cdromaneio = Left(cdromaneio, 10)
            Else
                cdromaneio = Left(String.Concat(cdromaneio, Space(10 - Len(cdromaneio))), 10)
            End If
            'fran 18/20/2009 f chamado 477

            'cd transportadora - CNPJ Transportadora - 15 posi��es
            cdtransportadora = FormataCampo(pCNPJTransportadora.Trim.ToString).Trim
            cdtransportadora = String.Concat(cdtransportadora, Space(15 - Len(cdtransportadora)))

            tpfrete = "2"
            cddoctovinculado = Space(12)
            If pcoletaNprogramada = "S" Then
                cddoctovinculado = "NPROGRAMADA "
            End If

            cdseriedoctovinculado = Space(3)

            'NATUREZA de OPERA��O
            'Fran 19/10/2009 i
            If Me.id_cooperativa > 0 Then
                cdnaturezaoperacao = Space(6)
            Else
                cdnaturezaoperacao = Space(6)
                'Verifica qual o estado da propriedade/produtotr
                Select Case pDadosPropriedade.Item("cd_uf")
                    Case "MG"
                        'Se NAO TEM incentivo 2,5, NAO TEM transf credito,  NAO TEM incentivo 2,1 e NAO TEM incentivo 2,4
                        If pDadosPropriedade.Item("st_incentivo_fiscal") = "N" And pDadosPropriedade.Item("st_transferencia_credito") = "N" And pDadosPropriedade.Item("st_incentivo_21") = "N" And pDadosPropriedade.Item("st_incentivo_24") = "N" Then
                            cdnaturezaoperacao = "1101  "
                        End If
                        'Se TEM incentivo 2,5, NAO TEM transf credito e NAO TEM incentivo 2,1
                        If pDadosPropriedade.Item("st_incentivo_fiscal") <> "N" And pDadosPropriedade.Item("st_transferencia_credito") = "N" And pDadosPropriedade.Item("st_incentivo_21") = "N" And pDadosPropriedade.Item("st_incentivo_24") = "N" Then
                            cdnaturezaoperacao = "1101  "
                        End If
                        'Se NAO TEM incentivo 2,5, TEM transf credito e NAO TEM incentivo 2,1
                        If pDadosPropriedade.Item("st_incentivo_fiscal") = "N" And pDadosPropriedade.Item("st_transferencia_credito") = "S" And pDadosPropriedade.Item("st_incentivo_21") = "N" And pDadosPropriedade.Item("st_incentivo_24") = "N" Then
                            cdnaturezaoperacao = "1101  "
                        End If
                        'Se NAO TEM incentivo 2,5, NAO TEM transf credito e TEM incentivo 2,1
                        If pDadosPropriedade.Item("st_incentivo_fiscal") = "N" And pDadosPropriedade.Item("st_transferencia_credito") = "N" And (pDadosPropriedade.Item("st_incentivo_21") = "S" Or pDadosPropriedade.Item("st_incentivo_24") = "S") Then
                            cdnaturezaoperacao = "1101  "
                        End If
                    Case "SP"
                        'Se NAO TEM incentivo 2,5, NAO TEM transf credito e NAO TEM incentivo 2,1
                        If pDadosPropriedade.Item("st_incentivo_fiscal") = "N" And pDadosPropriedade.Item("st_transferencia_credito") = "N" And pDadosPropriedade.Item("st_incentivo_21") = "N" And pDadosPropriedade.Item("st_incentivo_24") = "N" Then
                            'po�os dde caldas
                            If Me.id_estabelecimento = 1 Then
                                cdnaturezaoperacao = "2101  "
                            End If
                            'guara
                            If Me.id_estabelecimento = 2 Then
                                cdnaturezaoperacao = "1101  "
                            End If
                            '�guas prata
                            If Me.id_estabelecimento = 6 Then
                                cdnaturezaoperacao = "1101  "
                            End If
                        End If
                    Case "RJ"
                        'Se NAO TEM incentivo 2,5, NAO TEM transf credito e NAO TEM incentivo 2,1
                        If pDadosPropriedade.Item("st_incentivo_fiscal") = "N" And pDadosPropriedade.Item("st_transferencia_credito") = "N" And pDadosPropriedade.Item("st_incentivo_21") = "N" And pDadosPropriedade.Item("st_incentivo_24") = "N" Then
                            'guara
                            If Me.id_estabelecimento = 2 Then
                                cdnaturezaoperacao = "2101  "
                            End If
                        End If
                    Case Else
                        cdnaturezaoperacao = Space(6)
                End Select

            End If

            stisentoimposto = "N"
            stcreditoicms = "N"
            stitemsubtribnacompra = "N"
            'tpfinalidadeoperacao = "03" 'fran 23/10/2009
            tpfinalidadeoperacao = "02" 'fran 23/10/2009
            cdindfinanceiro = Space(10)
            stentregaurgente = "N"
            stfretediferenciado = "N"
            dttabpreco = Space(10)
            dtprevisaoentrega = Space(8)
            stexcluiitemdne = "N"
            stexcluirefext = "N"
            vrfretepgcliente = StrDup(15, "0")


            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            linhatexto = tpregistro + floperacao + tpdocumento + parceirocomercial + cdnota + cdserie + dtemissao
            linhatexto = linhatexto + dtembarque + tpentradasaida + pardestremet + dsenderecodestremet + dsbairrodestremet + nomecidade + uf + nrcepdestremet
            linhatexto = linhatexto + cdzonatransporte + cddocnegfrete + cdtiponota + cdequipamento + cdembalagem + cdmeiotransporte + cdterritorio
            linhatexto = linhatexto + dsseparadorconhecimento + dslote + cdromaneio + cdtransportadora + tpfrete + cddoctovinculado + cdseriedoctovinculado
            linhatexto = linhatexto + cdnaturezaoperacao + stisentoimposto + stcreditoicms + stitemsubtribnacompra + tpfinalidadeoperacao + cdindfinanceiro + stentregaurgente + stfretediferenciado
            linhatexto = linhatexto + dtentrega + chaverespfrete + dttabpreco + dtprevisaoentrega + stexcluiitemdne + stexcluirefext + vrfretepgcliente

            Frete_Registro_140 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function
    Private Function Frete_Registro_142(ByVal pCNPJEstabelRomaneio As String, ByVal pcnpjcpf As String, ByVal pproprietariotanque As String, Optional ByVal pnmabreviadotecnico As String = "", Optional ByVal pId_coleta As String = "0") As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim parceirocoml As String   'Num 15 posi��es
            Dim cdnota As String   'Num 12 posi��es
            Dim cdserie As String   'Num 2 posi��es
            Dim codref1 As String '15 posi��es
            Dim dsref1 As String  '15 posi��es
            Dim codref2 As String '15 posi��es
            Dim dsref2 As String  '15 posi��es
            Dim codref3 As String '15 posi��es
            Dim dsref3 As String  '15 posi��es
            Dim codref4 As String '15 posi��es
            Dim dsref4 As String  '15 posi��es
            Dim codref5 As String '15 posi��es
            Dim dsref5 As String  '15 posi��es
            Dim codref6 As String '15 posi��es
            Dim dsref6 As String  '15 posi��es
            Dim codref7 As String '15 posi��es
            Dim dsref7 As String  '15 posi��es
            Dim codref8 As String '15 posi��es
            Dim dsref8 As String  '15 posi��es
            '====================================================================================
            ' Registro Tipo 142
            '====================================================================================

            'Tipo de Registro - Fixo 142
            tpregistro = "142"

            parceirocoml = FormataCampo(pcnpjcpf.ToString) 'fran 18/10/2009 i chamado 477
            If Len(parceirocoml.Trim) > 15 Then
                parceirocoml = Left(parceirocoml.Trim, 15)
            Else
                parceirocoml = String.Concat(parceirocoml.Trim, Space(15 - Len(parceirocoml.Trim)))
            End If

            'cnpj romaneio
            'codref1 = Left(String.Concat(pCNPJEstabelRomaneio, Space(15 - Len(pCNPJEstabelRomaneio))), 15) 'fran 18/10/2009 chamado 477

            If Me.id_cooperativa > 0 Then
                'fran 18/10/2009 i chamado 477
                'If Len(Me.nr_nota_fiscal) + Len(Me.nr_serie_nota_fiscal) >= 15 Then
                '    dsref1 = Left(String.Concat(Me.nr_nota_fiscal, Me.nr_serie_nota_fiscal), 15)
                'Else
                '    dsref1 = Left(String.Concat(Me.nr_nota_fiscal, Me.nr_serie_nota_fiscal, Space(15 - (Len(Me.nr_nota_fiscal) + Len(Me.nr_serie_nota_fiscal)))), 15)
                'End If
                cdnota = Me.nr_nota_fiscal.ToString.Trim
                If Len(cdnota) > 12 Then
                    cdnota = Left(cdnota, 12)
                Else
                    cdnota = Left(String.Concat(cdnota, Space(12 - Len(cdnota))), 12)
                End If

                cdserie = Me.nr_serie_nota_fiscal.ToString.Trim
                If Len(cdserie) > 3 Then
                    cdserie = Left(cdserie, 3)
                Else
                    cdserie = Left(String.Concat(cdserie, Space(3 - Len(cdserie))), 3)
                End If

                'fran 18/10/2009 f chamado 477
                codref1 = String.Concat("CANAL", Space(10))
                dsref1 = String.Concat("COOPERATIVA", Space(4))
            Else
                'fran 18/10/2009 i chamado 477
                'If Len(pId_coleta) >= 15 Then
                '    dsref1 = Left(pId_coleta, 15)
                'Else
                '    dsref1 = Left(String.Concat(pId_coleta, Space(15 - Len(pId_coleta))), 15)
                'End If
                If Len(pId_coleta) > 12 Then
                    cdnota = Left(pId_coleta, 12)
                Else
                    cdnota = Left(String.Concat(pId_coleta, Space(12 - Len(pId_coleta))), 12)
                End If
                cdserie = "DAL"
                codref1 = String.Concat("CANAL", Space(10))
                dsref1 = String.Concat("PRODUTOR", Space(7))
                'fran 18/10/2009 f chamado 477
            End If

            'fran 18/10/2009 i chamado 477
            'codref2 = String.Concat("CANAL", Space(10))
            'dsref2 = Space(15)
            'codref3 = Space(15)
            'dsref3 = Space(15)
            'codref4 = "TIPO TRANSPORTE"
            'dsref4 = String.Concat("PRIMARIO", Space(7))
            'codref5 = String.Concat("TIPO DE BAU", Space(4))
            'dsref5 = String.Concat("PROPRIO", Space(8))
            'codref6 = String.Concat("ROTEIRO", Space(8))
            'dsref6 = String.Concat(Me.nm_linha, Space(15 - Len(nm_linha)))
            'codref7 = Space(15)
            'dsref7 = Space(15)
            'codref8 = Space(15)
            'dsref8 = Space(15)

            codref2 = String.Concat("OCORRENCIA", Space(5))
            dsref2 = Space(15)
            codref3 = "TIPO TRANSPORTE"
            dsref3 = String.Concat("DAL", Space(12))
            codref4 = String.Concat("TIPO DE BAU", Space(4))
            dsref4 = Space(15)
            If pproprietariotanque.ToString.Trim = "T" Then
                dsref4 = String.Concat("PROPRIO", Space(8))
            End If
            If pproprietariotanque.ToString.Trim = "D" Then
                dsref4 = String.Concat("DANONE", Space(9))
            End If
            codref5 = String.Concat("ROTEIRO", Space(8))
            dsref5 = String.Concat(Me.nm_linha, Space(15 - Len(nm_linha)))
            codref6 = Space(15)
            dsref6 = Space(15)
            codref7 = String.Concat("GER_REGIO", Space(6))
            dsref7 = String.Concat(pnmabreviadotecnico, Space(15 - Len(pnmabreviadotecnico)))
            codref8 = String.Concat("TIPONF", Space(9))
            dsref8 = String.Concat("1", Space(14))
            'fran 18/10/2009 f chamado 477

            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            'fran 18/10/2009 i chamado 477
            'linhatexto = tpregistro + dsref1 + codref2 + dsref2 + codref3 + dsref3 + codref4 + dsref4
            linhatexto = tpregistro + parceirocoml + cdnota + cdserie + codref1 + dsref1 + codref2 + dsref2 + codref3 + dsref3 + codref4 + dsref4
            linhatexto = linhatexto + codref5 + dsref5 + codref6 + dsref6 + codref7 + dsref7 + codref8 + dsref8

            Frete_Registro_142 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function
    Private Function Frete_Registro_120(ByVal pCdItem As String, ByVal pNmItem As String, ByVal ptotallitros As String, ByVal pMediaDensidade As String) As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim floperacao As String '1 posi��es
            Dim dsitem As String  '40 posi��es
            Dim cditem As String '20 posi��es
            Dim cditemcategoria As String  '10 posi��es
            Dim cditemcategoria2 As String '10 posi��es
            Dim unidade1 As String  '3 posi��es
            Dim qtref1 As String '7 posi��es
            Dim peso1 As String  '7 posi��es
            Dim unidade2 As String  '3 posi��es
            Dim qtref2 As String '7 posi��es
            Dim peso2 As String  '7 posi��es
            Dim unidade3 As String  '3 posi��es
            Dim qtref3 As String '7 posi��es
            Dim peso3 As String  '7 posi��es
            Dim unidade4 As String  '3 posi��es
            Dim qtref4 As String '7 posi��es
            Dim peso4 As String  '7 posi��es
            '====================================================================================
            ' Registro Tipo 120
            '====================================================================================
            Dim lvalorint As String
            Dim lvalordec As String
            Dim lpos As Integer

            'Tipo de Registro - Fixo 120
            tpregistro = "120"

            floperacao = "A"

            dsitem = pNmItem
            dsitem = String.Concat(dsitem, Space(40 - Len(dsitem)))

            cditem = pCdItem
            cditem = String.Concat(cditem, Space(20 - Len(cditem)))

            cditemcategoria = Space(10)
            'cditemcategoria2 = Space(10) 'fran 23/10/2009
            cditemcategoria2 = String.Concat("1", Space(9)) 'fran 23/10/2009
            'Fran 18/10/2009 i chamado 477
            'unidade1 = "LT "
            unidade1 = "L  "
            'Fran 18/10/2009 f chamado 477

            'qtref1 = StrDup(7, "0") 'Fran 28/10/2009 i
            If ptotallitros.Equals(String.Empty) Then
                ptotallitros = "0"
            End If
            lpos = InStr(1, ptotallitros, ",")
            If lpos > 0 Then
                lvalorint = Mid(ptotallitros, 1, lpos - 1)
            Else
                lvalorint = ptotallitros
            End If
            'Fran 28/10/2009 i
            'peso1 = Right(String.Concat(StrDup(7 - Len(lvalorint), "0"), lvalorint), 7)

            If Len(lvalorint) > 5 Then
                qtref1 = Left(lvalorint, 5)
            Else
                qtref1 = Right(String.Concat(StrDup(5 - Len(lvalorint), "0"), lvalorint), 5)
            End If
            '7 posicoes 5 inteiro 2 decimais
            qtref1 = String.Concat(qtref1, "00")

            'peso 1 7 posi��e - 5 inteiro e 2 decimais
            peso1 = Round(CDec(ptotallitros) * pMediaDensidade, 2).ToString

            lpos = InStr(1, peso1, ",")
            If lpos > 0 Then
                lvalorint = Mid(peso1, 1, lpos - 1)
                lvalordec = Mid(peso1, lpos + 1)
                If Len(lvalorint) > 5 Then
                    lvalorint = Left(lvalorint, 5)
                Else
                    lvalorint = Right(String.Concat(StrDup(5 - Len(lvalorint), "0"), lvalorint), 5)
                End If
                If Len(lvalordec) > 2 Then
                    lvalordec = Left(lvalordec, 2)
                Else
                    lvalordec = Left(String.Concat(lvalordec, StrDup(2 - Len(lvalordec), "0")), 2)
                End If

            Else
                lvalorint = peso1
                If Len(lvalorint) > 5 Then
                    lvalorint = Left(lvalorint, 5)
                Else
                    lvalorint = Right(String.Concat(StrDup(5 - Len(lvalorint), "0"), lvalorint), 5)
                End If
                lvalordec = "00"
            End If

            peso1 = Right(String.Concat(lvalorint, lvalordec), 7)
            'fran 28/10/2009 f
            unidade2 = Space(3)
            qtref2 = StrDup(7, "0")
            peso2 = StrDup(7, "0")

            unidade3 = Space(3)
            qtref3 = StrDup(7, "0")
            peso3 = StrDup(7, "0")

            unidade4 = Space(3)
            qtref4 = StrDup(7, "0")
            peso4 = StrDup(7, "0")


            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            linhatexto = tpregistro + floperacao + dsitem + cditem + cditemcategoria + cditemcategoria2
            linhatexto = linhatexto + unidade1 + qtref1 + peso1 + unidade2 + qtref2 + peso2
            linhatexto = linhatexto + unidade3 + qtref3 + peso3 + unidade4 + qtref4 + peso4

            Frete_Registro_120 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function

    Private Function Frete_Registro_160(ByVal pCdItem As String, ByVal pNrLitrosColeta As String, ByVal pCNPJEstabel As String, ByVal pMediaDensidade As Decimal, Optional ByVal pId_coleta As String = "0", Optional ByVal ppreconegociado As String = "0") As String


        Try

            Dim linhatexto As String
            ' Registro 000
            Dim tpregistro As String   'Num 3 posi��es
            Dim floperacao As String '1 posi��es
            Dim chaveemitente As String
            Dim cdnota As String
            Dim cdserie As String
            Dim nrnotaitem As String
            Dim cditem As String
            Dim vlnotaitem As String
            Dim qtpesobruto As String
            Dim qtpesocubado As String
            Dim qtpesoliquido As String
            Dim qtvolume As String
            Dim vlcubagem As String
            Dim cdcontacontabil As String
            Dim cdcentrocusto As String
            Dim qtitem As String
            Dim dsuniitem As String
            Dim vlfretepgclitab As String
            Dim vlfretepgcliente As String
            Dim lpos As Integer
            Dim lvalorint As String
            Dim lvalordec As String
            Dim lvaloritemnota As Decimal
            '
            Dim parceirocomercial As String 'fran 18/10/2009

            '====================================================================================
            ' Registro Tipo 160
            '====================================================================================

            'Tipo de Registro - Fixo 160
            tpregistro = "160"

            floperacao = "A"
            'fran 18/10/2009 i chamado 477
            'If Len(Me.id_romaneio) >= 15 Then
            '    chaveemitente = Left(Me.id_romaneio.ToString, 15)
            'Else
            '    chaveemitente = Left(String.Concat(Me.id_romaneio.ToString, Space(15 - Len(Me.id_romaneio.ToString))), 15)
            'End If
            'parceirocomercial - CNPJ do estabelecimento do romaneio - 15 posi��es
            parceirocomercial = FormataCampo(pCNPJEstabel.Trim.ToString).Trim
            parceirocomercial = String.Concat(parceirocomercial, Space(15 - Len(parceirocomercial)))
            'fran 18/10/2009 f chamado 477


            If Me.id_cooperativa > 0 Then
                cdnota = Left(String.Concat(Me.nr_nota_fiscal.ToString, Space(12 - Len(Me.nr_nota_fiscal.ToString))), 12)
                cdserie = Left(String.Concat(Me.nr_serie_nota_fiscal.ToString, Space(3 - Len(Me.nr_serie_nota_fiscal.ToString))), 3)
                'Fran 28/10/2009 i
                'qtpesobruto = Me.nr_peso_liquido_nota.ToString
                qtpesobruto = Round(Me.nr_peso_liquido_nota * pMediaDensidade, 2).ToString
                qtitem = Me.nr_peso_liquido_nota.ToString
                'Fran 28/10/2009 f
            Else
                'fran 18/10/2009 i chamado 477
                'If Len(Me.id_romaneio) >= 12 Then
                '    cdnota = Left(Me.id_romaneio.ToString, 12)
                'Else
                '    cdnota = Left(String.Concat(Me.id_romaneio.ToString, Space(12 - Len(Me.id_romaneio.ToString))), 12)
                'End If
                'cdserie = Space(3)
                If Len(pId_coleta) > 12 Then
                    cdnota = Left(pId_coleta.ToString, 12)
                Else
                    cdnota = Left(String.Concat(pId_coleta.ToString, Space(12 - Len(pId_coleta.ToString))), 12)
                End If
                cdserie = "DAL"

                'fran 18/10/2009 f chamado 477
                'Fran 28/10/2009 i
                'qtpesobruto = pNrLitrosColeta
                If pNrLitrosColeta.Equals(String.Empty) Then
                    pNrLitrosColeta = "0"
                End If
                qtpesobruto = Round(CDec(pNrLitrosColeta) * pMediaDensidade, 2).ToString
                qtitem = pNrLitrosColeta
                'Fran 28/10/2009 f
            End If
            'Fran 28/10/2009 i
            lpos = InStr(1, qtpesobruto, ",")
            If lpos > 0 Then
                lvalorint = Mid(qtpesobruto, 1, lpos - 1)
                lvalordec = Mid(qtpesobruto, lpos + 1)
            Else
                lvalorint = qtpesobruto
                lvalordec = "00"
            End If
            If Len(lvalorint) > 13 Then
                lvalorint = Left(lvalorint, 13)
            Else
                lvalorint = Right(String.Concat(StrDup(13 - Len(lvalorint), "0"), lvalorint), 13)
            End If
            If Len(lvalordec) > 2 Then
                lvalordec = Left(lvalordec, 2)
            Else
                lvalordec = Left(String.Concat(lvalordec, StrDup(2 - Len(lvalordec), "0")), 2)
            End If
            qtpesobruto = String.Concat(lvalorint, lvalordec)
            'Fran 28/10/2009 f

            nrnotaitem = "001" 'Numero seuqencial de itens. NO MIlk sempre temos apena um item por coleta (leite)

            cditem = pCdItem
            cditem = String.Concat(cditem, Space(20 - Len(cditem)))

            qtpesobruto = Right(String.Concat(StrDup(15 - Len(qtpesobruto), "0"), qtpesobruto), 15)

            qtpesocubado = StrDup(15, "0")

            qtpesoliquido = qtpesobruto

            'vlnotaitem = StrDup(12, "0")
            'fran 23/10/2009 i 
            'vlnotaitem = Right(qtpesobruto, 12)
            'qtvolume = StrDup(4, "0")
            ' 10 inteiros, sem virgula  e 2 decimais (12 caracteres)
            If Me.id_cooperativa > 0 Then
                lvaloritemnota = Round((Me.nr_valor_nota_fiscal / Me.nr_peso_liquido_nota), 2)
                If lvaloritemnota > 0 Then
                    lpos = InStr(1, lvaloritemnota.ToString, ",")
                    If lpos = 0 Then   ' Se n�o tem casas decimais
                        vlnotaitem = Right(String.Concat(StrDup(10 - Len(lvaloritemnota.ToString.Trim), "0"), lvaloritemnota.ToString.Trim), 10)
                        vlnotaitem = String.Concat(vlnotaitem, "00")
                    Else
                        lvalorint = CStr(Left(lvaloritemnota.ToString, lpos - 1))  ' Pegar somente o valor inteiro
                        lvalorint = Right(String.Concat(StrDup(10 - Len(lvalorint.Trim), "0"), lvalorint), 10)
                        lvalordec = CStr(Mid(CStr(lvaloritemnota.ToString), lpos + 1))  ' Pegar somente o valor decimal
                        If Len(lvalordec) >= 2 Then
                            lvalordec = Left(lvalordec, 2)
                        Else
                            lvalordec = Left(String.Concat(lvalordec, StrDup(2 - Len(lvalordec), "0")), 2)
                        End If

                        vlnotaitem = Right(String.Concat(lvalorint, lvalordec).Trim, 12)
                    End If
                Else
                    vlnotaitem = StrDup(12, "0")
                End If

            Else
                If CInt(ppreconegociado) > 0 Then
                    lpos = InStr(1, ppreconegociado, ",")
                    If lpos = 0 Then   ' Se n�o tem casas decimais
                        vlnotaitem = Right(String.Concat(StrDup(10 - Len(ppreconegociado.Trim), "0"), ppreconegociado), 10)
                        vlnotaitem = String.Concat(vlnotaitem, "00")
                    Else
                        lvalorint = CStr(Left(ppreconegociado, lpos - 1))  ' Pegar somente o valor inteiro
                        lvalorint = Right(String.Concat(StrDup(10 - Len(lvalorint.Trim), "0"), lvalorint), 10)
                        lvalordec = CStr(Mid(CStr(ppreconegociado), lpos + 1))  ' Pegar somente o valor decimal
                        If Len(lvalordec) >= 2 Then
                            lvalordec = Left(lvalordec, 2)
                        Else
                            lvalordec = Left(String.Concat(lvalordec, StrDup(2 - Len(lvalordec), "0")), 2)
                        End If

                        vlnotaitem = Right(String.Concat(lvalorint, lvalordec).Trim, 12)
                    End If
                Else
                    vlnotaitem = StrDup(12, "0")
                End If

            End If

            qtvolume = "0001"
            'fran 23/10/2009 f

            vlcubagem = StrDup(10, "0")
            cdcontacontabil = Space(15)
            cdcentrocusto = Space(10)
            'Fran 30/10/2009 i 
            'qtitem = qtpesobruto
            lpos = InStr(1, qtitem.Trim, ",")
            If lpos > 0 Then
                qtitem = Left(qtitem, lpos - 1)
            End If
            If Len(qtitem.Trim) >= 13 Then
                qtitem = String.Concat(Left(qtitem.Trim, 13), "00")
            Else
                qtitem = String.Concat(Right(String.Concat(StrDup(13 - Len(qtitem.Trim), "0"), qtitem.Trim), 13), "00")
            End If
            'Fran 30/10/2009 f

            'dsuniitem = "LT "
            dsuniitem = "L  "
            vlfretepgclitab = StrDup(15, "0")
            vlfretepgcliente = StrDup(15, "0")
            linhatexto = ""

            'Monta a linha a ser inserida no arquivo texto
            'linhatexto = tpregistro + floperacao + chaveemitente + cdnota + cdserie + nrnotaitem
            linhatexto = tpregistro + floperacao + parceirocomercial + cdnota + cdserie + nrnotaitem
            linhatexto = linhatexto + cditem + vlnotaitem + qtpesobruto + qtpesocubado + qtpesoliquido + qtvolume
            linhatexto = linhatexto + vlcubagem + cdcontacontabil + cdcentrocusto + qtitem + dsuniitem + vlfretepgclitab + vlfretepgcliente

            Frete_Registro_160 = formatarTexto(linhatexto)

        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try
    End Function
    Public Function exportFrete() As Boolean

        Dim ArquivoTexto As StreamWriter

        Try

            Dim nomearquivo As String
            Dim filtro_estabel As Int32
            Dim filtro_id_romaneio As Int32
            Dim filtro_dt_ini As String
            Dim filtro_dt_fim As String
            Dim filtro_path_arquivofrete As String
            Dim id_frete_execucao As Int32
            Dim lrow As DataRow
            Dim lrowcoleta As DataRow
            Dim ltransportadora_ant As Int32
            Dim linhaarquivo As String
            Dim cnpjtransportadora As String
            Dim cnpjprodutor As String

            Dim propriedade As New Propriedade
            Dim Calculo As New CalculoProdutor
            Dim dspropriedade As DataSet
            Dim pessoa As New Pessoa
            Dim Item As New Item
            Dim veiculo As New Veiculo
            Dim freteexecucao As New ExportacaoFreteExecucao
            Dim parametro As New Parametro
            Dim lmediaDensidade As Decimal


            filtro_estabel = Me.id_estabelecimento
            filtro_id_romaneio = Me.id_romaneio
            filtro_dt_ini = Me.dt_hora_entrada_ini
            filtro_dt_fim = Me.dt_hora_entrada_fim
            filtro_path_arquivofrete = Me.path_arquivofrete
            id_frete_execucao = Me.id_exportacao_frete_execucao

            freteexecucao.id_exportacao_frete_execucao = id_frete_execucao
            Dim dsfreteexecucao As DataSet = freteexecucao.getExportacaoFreteExecucaoItensByFilters

            Dim estabelromaneio As New Estabelecimento(Me.id_estabelecimento)
            Dim dsestabel As DataSet = estabelromaneio.getEstabelecimentoByFilters
            Dim dsDadosCooperativa As DataSet
            Dim dsDadosColetas As DataSet
            Dim dsprodutor As DataSet
            Dim dsitem As DataSet
            Dim dsveiculo As DataSet
            Dim lpreconegociado As Decimal
            Dim lbregistro060executado As Boolean = False
            nomearquivo = String.Empty

            'Para cada linha do sql que traz os romaneios agrupados por transportadora e placa
            For Each lrow In dsfreteexecucao.Tables(0).Rows
                'reinicializa romaneio
                Me.id_romaneio = lrow.Item("id_romaneio")
                Me.Finalize()
                Me.reloadRomaneio()
                lmediaDensidade = Me.getRomaneioCompartimentoMediaDens 'fran 28/10/2009
                Me.id_exportacao_frete_execucao_itens = lrow.Item("id_exportacao_frete_execucao_itens")
                Me.id_exportacao_frete_execucao = id_frete_execucao
                If ltransportadora_ant <> lrow.Item("id_transportadora") Then
                    'Se ainda tem nome de arquivo fecha arquivo anterior
                    If Not nomearquivo.ToString.Trim.Equals(String.Empty) Then
                        'fecha arquivo anterior
                        ArquivoTexto.Close()
                        ArquivoTexto.Dispose()
                    End If
                    'abre novo arquivo
                    nomearquivo = "\cltes-milk_" + estabelromaneio.cd_estabelecimento.Trim + "_" + DateTime.Parse(Me.dt_hora_entrada).ToString("ddMMyyyy") + "_" + DateTime.Parse(Me.dt_modificacao).ToString("ddMMyyyy") + "_" + DateTime.Parse(Now()).ToString("ddMMyyyyHHmmss") + ".txt"
                    nomearquivo = Replace(nomearquivo, ":", "")
                    nomearquivo = Replace(nomearquivo, " ", "")
                    nomearquivo = Replace(nomearquivo, "/", "")
                    nomearquivo = filtro_path_arquivofrete & nomearquivo
                    ArquivoTexto = New StreamWriter(nomearquivo)

                    ltransportadora_ant = lrow.Item("id_transportadora")

                    pessoa.id_pessoa = Convert.ToInt32(lrow.Item("id_transportadora"))
                    cnpjtransportadora = FormataCampo(pessoa.getCNPJPessoa)

                    'Gera registro 000
                    linhaarquivo = Me.Frete_Registro_000
                    ArquivoTexto.WriteLine(linhaarquivo)

                End If

                'Grava execucao itens
                freteexecucao.id_exportacao_frete_execucao_itens = lrow.Item("id_exportacao_frete_execucao_itens")
                freteexecucao.nm_arquivo = nomearquivo
                freteexecucao.st_exportacao_frete_execucao_itens = "I" 'inicializada

                'busca dadps do item do romaneio
                Item.id_item = Me.id_item
                dsitem = Item.getItensByFilters

                'busca dados do veiculo
                Me.ds_placa_frete = lrow.Item("ds_placa_frete").ToString.Trim
                veiculo.ds_placa = Me.ds_placa_frete
                dsveiculo = veiculo.getVeiculoByFilters



                'Fran 26/10/2009 i - desabilitado pois rotina ser� chamada para cooperativa ou para produtor pois tem valores especificos
                'Gera registro 060 
                ''linhaarquivo = Me.Frete_Registro_060(FormataCampo(estabelromaneio.cd_cnpj), estabelromaneio.cd_estabelecimento, estabelromaneio.nm_cidade, estabelromaneio.cd_uf, cnpjtransportadora.ToString, lrow.Item("ds_placa_frete").ToString.Trim, lrow.Item("cd_tipo_equipamento").ToString)
                'linhaarquivo = Me.Frete_Registro_060(FormataCampo(estabelromaneio.cd_cnpj), estabelromaneio.cd_estabelecimento, estabelromaneio.nm_cidade, estabelromaneio.cd_uf, cnpjtransportadora.ToString, lrow.Item("ds_placa_frete").ToString.Trim, dsveiculo.Tables(0).Rows(0).Item("nm_tipo_equipamento").ToString.Trim)
                'ArquivoTexto.WriteLine(linhaarquivo)
                lbregistro060executado = False
                'Fran 26/10/2009 f - desabilitado pois rotina ser� chamada para cooperativa ou para produtor pois tem valores especificos

                If Me.id_cooperativa > 0 Then

                    'Fran 26/10/2009 i - 
                    'Gera registro 060 
                    linhaarquivo = Me.Frete_Registro_060(FormataCampo(estabelromaneio.cd_cnpj), estabelromaneio.cd_estabelecimento, estabelromaneio.nm_cidade, estabelromaneio.cd_uf, cnpjtransportadora.ToString, lrow.Item("ds_placa_frete").ToString.Trim, dsveiculo.Tables(0).Rows(0).Item("nm_tipo_equipamento").ToString.Trim)
                    ArquivoTexto.WriteLine(linhaarquivo)
                    'Fran 26/10/2009 f 

                    pessoa.id_pessoa = Me.id_cooperativa
                    dsDadosCooperativa = pessoa.getPessoaByFilters

                    'Gera registro 100
                    linhaarquivo = Me.Frete_Registro_100(dsestabel.Tables(0).Rows(0), dsDadosCooperativa.Tables(0).Rows(0))
                    ArquivoTexto.WriteLine(linhaarquivo)

                    'Gera registro 140
                    'Fran 19/10/2009 i
                    'linhaarquivo = Me.Frete_Registro_140(cnpjtransportadora,  lrow.Item("cd_tipo_equipamento"), , , dsestabel.Tables(0).Rows(0), dsDadosCooperativa.Tables(0).Rows(0))
                    linhaarquivo = Me.Frete_Registro_140(cnpjtransportadora, dsveiculo.Tables(0).Rows(0).Item("nm_tipo_equipamento"), , , dsestabel.Tables(0).Rows(0), dsDadosCooperativa.Tables(0).Rows(0))
                    'Fran 19/10/2009 f
                    ArquivoTexto.WriteLine(linhaarquivo)

                    'Gera registro 142
                    linhaarquivo = Me.Frete_Registro_142(estabelromaneio.cd_cnpj, dsDadosCooperativa.Tables(0).Rows(0).Item("cd_cnpj").ToString, dsveiculo.Tables(0).Rows(0).Item("ds_proprietario_tanque"))
                    ArquivoTexto.WriteLine(linhaarquivo)

                    'Gera registro 120
                    linhaarquivo = Me.Frete_Registro_120(dsitem.Tables(0).Rows(0).Item("cd_item").ToString.Trim, dsitem.Tables(0).Rows(0).Item("nm_item").ToString.Trim, Me.nr_peso_liquido_nota.ToString.Trim, lmediaDensidade)
                    ArquivoTexto.WriteLine(linhaarquivo)

                    'Gera registro 160
                    linhaarquivo = Me.Frete_Registro_160(dsitem.Tables(0).Rows(0).Item("cd_item").ToString.Trim, Me.nr_peso_liquido_nota.ToString.Trim, estabelromaneio.cd_cnpj, lmediaDensidade)
                    ArquivoTexto.WriteLine(linhaarquivo)

                Else
                    'Busca as coletas para a caderneta e a placa_frete
                    Me.ds_placa_frete = lrow.Item("ds_placa_frete").ToString.Trim
                    dsDadosColetas = Me.getFreteColetas


                    For Each lrowcoleta In dsDadosColetas.Tables(0).Rows
                        propriedade.id_propriedade = lrowcoleta.Item("id_propriedade")
                        dspropriedade = propriedade.getPropriedadeByFilters()
                        pessoa.id_pessoa = Convert.ToInt32(dspropriedade.Tables(0).Rows(0).Item("id_pessoa").ToString.Trim)
                        dsprodutor = pessoa.getPessoaByFilters

                        'Fran 26/10/2009 i - se for 1a vez...
                        If lbregistro060executado = False Then
                            'Gera registro 060 
                            linhaarquivo = Me.Frete_Registro_060(FormataCampo(estabelromaneio.cd_cnpj), estabelromaneio.cd_estabelecimento, estabelromaneio.nm_cidade, estabelromaneio.cd_uf, cnpjtransportadora.ToString, lrow.Item("ds_placa_frete").ToString.Trim, dsveiculo.Tables(0).Rows(0).Item("nm_tipo_equipamento").ToString.Trim, dsprodutor.Tables(0).Rows(0).Item("nm_cidade"), dsprodutor.Tables(0).Rows(0).Item("cd_uf"))
                            ArquivoTexto.WriteLine(linhaarquivo)
                            lbregistro060executado = True
                        End If
                        'Fran 26/10/2009 f 

                        Calculo.dt_referencia = DateAdd(DateInterval.Month, -1, Convert.ToDateTime(String.Concat("01/", DateTime.Parse(Me.dt_hora_entrada).ToString("MM/yyyy"))))
                        Calculo.id_propriedade = propriedade.id_propriedade
                        lpreconegociado = Calculo.getCalculoPrecoNegociado().ToString
                        lpreconegociado = lpreconegociado - parametro.nr_deflator

                        'Gera registro 100
                        linhaarquivo = Me.Frete_Registro_100(dsestabel.Tables(0).Rows(0), , dsprodutor.Tables(0).Rows(0))
                        ArquivoTexto.WriteLine(linhaarquivo)

                        'Gera registro 140
                        linhaarquivo = Me.Frete_Registro_140(cnpjtransportadora, dsveiculo.Tables(0).Rows(0).Item("nm_tipo_equipamento").ToString.Trim, lrowcoleta.Item("id_coleta").ToString.Trim, lrowcoleta.Item("st_coleta_nao_programada").ToString.Trim, dsestabel.Tables(0).Rows(0), , dsprodutor.Tables(0).Rows(0), dspropriedade.Tables(0).Rows(0))
                        ArquivoTexto.WriteLine(linhaarquivo)

                        'Gera registro 142
                        If dsprodutor.Tables(0).Rows(0).Item("cd_cpf").Equals(String.Empty) Then
                            linhaarquivo = Me.Frete_Registro_142(estabelromaneio.cd_cnpj, dsprodutor.Tables(0).Rows(0).Item("cd_cnpj"), dsveiculo.Tables(0).Rows(0).Item("ds_proprietario_tanque").ToString.Trim, dspropriedade.Tables(0).Rows(0).Item("nm_abreviado_tecnico"), lrowcoleta.Item("id_coleta").ToString.Trim)
                        Else
                            linhaarquivo = Me.Frete_Registro_142(estabelromaneio.cd_cnpj, dsprodutor.Tables(0).Rows(0).Item("cd_cpf"), dsveiculo.Tables(0).Rows(0).Item("ds_proprietario_tanque").ToString.Trim, dspropriedade.Tables(0).Rows(0).Item("nm_abreviado_tecnico"), lrowcoleta.Item("id_coleta").ToString.Trim)
                        End If
                        ArquivoTexto.WriteLine(linhaarquivo)

                        'Gera registro 120
                        linhaarquivo = Me.Frete_Registro_120(dsitem.Tables(0).Rows(0).Item("cd_item").ToString.Trim, dsitem.Tables(0).Rows(0).Item("nm_item").ToString.Trim, lrowcoleta.Item("nr_litros").ToString.Trim, lmediaDensidade)
                        ArquivoTexto.WriteLine(linhaarquivo)

                        'Gera registro 160
                        linhaarquivo = Me.Frete_Registro_160(dsitem.Tables(0).Rows(0).Item("cd_item").ToString.Trim, lrowcoleta.Item("nr_litros").ToString.Trim, estabelromaneio.cd_cnpj, lmediaDensidade, lrowcoleta.Item("id_coleta").ToString.Trim, lpreconegociado.ToString)
                        ArquivoTexto.WriteLine(linhaarquivo)

                    Next
                End If

                'finaliza na item execucao e no romaneio se nao houver mais de um registro romaneio (transportadoreas diferentes)
                freteexecucao.st_exportacao_frete_execucao_itens = "F"
                freteexecucao.updateExportacaoFreteExecucaoItens() 'atualiza status
                If lrow.Item("nr_qtde_romaneio_execucao") = 1 Then
                    Me.st_exportacao_frete = "S" 'atualiza status exportacao frete do romaneio 
                    Me.updateRomaneioStatusFreteExportacao()
                End If
            Next


            ArquivoTexto.Close()
            'Finaliza execu��o (romaneios e execucao)
            freteexecucao.id_exportacao_frete_execucao = id_frete_execucao
            freteexecucao.updateFreteExportacaoStatusFinalizacao()

            exportFrete = True

        Catch ex As Exception
            exportFrete = False   ' 01/12/2008
            Dim execucaoerro As New ExportacaoFreteExecucao
            execucaoerro.st_exportacao_frete_execucao = "E"
            execucaoerro.id_exportacao_frete_execucao = Me.id_exportacao_frete_execucao
            execucaoerro.id_exportacao_frete_execucao_itens = Me.id_exportacao_frete_execucao_itens
            execucaoerro.nm_erro = ex.Message
            execucaoerro.insertExportacaoFreteExecucaoErro()
            execucaoerro.updateExportacaoFreteExecucao()
            If Not ArquivoTexto Is Nothing Then
                ArquivoTexto.Close()
            End If

            Throw New Exception(ex.Message)

        End Try

    End Function
    Private Function FormataCampo(ByVal pString) As String


        Try

            Dim lString As String

            lString = pString
            lString = Replace(lString, ".", "")
            lString = Replace(lString, "/", "")
            lString = Replace(lString, "-", "")

            formatacampo = lString



        Catch ex As Exception
            ' ArquivoTexto.Close()
            Throw New Exception(ex.Message)

        End Try

    End Function
    Public Sub updateRomaneioStatusFreteExportacao()

        Using data As New DataAccess

            Dim parameters As List(Of Parameters) = ParametersEngine.getParametersFromObject(Me)
            data.Execute("ms_updateRomaneioFreteExportacao", parameters, ExecuteType.Update)

        End Using

    End Sub
    Private Function formatarTexto(ByVal texto As String) As String
        Try
            Dim ltexto As String

            ltexto = texto

            ltexto = Replace(ltexto, "�", "a")
            ltexto = Replace(ltexto, "�", "a")
            ltexto = Replace(ltexto, "�", "a")
            ltexto = Replace(ltexto, "�", "A")
            ltexto = Replace(ltexto, "�", "A")
            ltexto = Replace(ltexto, "�", "A")
            ltexto = Replace(ltexto, "�", "e")
            ltexto = Replace(ltexto, "�", "e")
            ltexto = Replace(ltexto, "�", "E")
            ltexto = Replace(ltexto, "�", "E")
            ltexto = Replace(ltexto, "�", "i")
            ltexto = Replace(ltexto, "�", "I")
            ltexto = Replace(ltexto, "�", "o")
            ltexto = Replace(ltexto, "�", "o")
            ltexto = Replace(ltexto, "�", "o")
            ltexto = Replace(ltexto, "�", "O")
            ltexto = Replace(ltexto, "�", "O")
            ltexto = Replace(ltexto, "�", "O")
            ltexto = Replace(ltexto, "�", "u")
            ltexto = Replace(ltexto, "�", "U")
            ltexto = Replace(ltexto, "�", "u")
            ltexto = Replace(ltexto, "�", "U")
            ltexto = Replace(ltexto, "'", " ")
            ltexto = Replace(ltexto, "�", "c")
            ltexto = Replace(ltexto, "�", "C")
            ltexto = Replace(ltexto, ",", " ")


            formatarTexto = ltexto
        Catch ex As Exception
            Throw New Exception(ex.Message)

        End Try
    End Function

End Class
